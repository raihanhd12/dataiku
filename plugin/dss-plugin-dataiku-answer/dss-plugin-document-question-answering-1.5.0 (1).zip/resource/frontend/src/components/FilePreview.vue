<template>
  <div :style="imgStyle">
    <img
      :src="image"
      class="file-preview"
      :style="imgStyle"
      loading="lazy"
      spinner-color="blue"
      @load="emits('loaded')"
      @click="showImage = true"
    />
    <q-dialog v-model="showImage" v-if="downloadable">
      <q-card class="file-preview-card">
          <div class="row items-center justify-between">
            <BsButton name="download-icon">
              <DownloadIcon
                @click="emits('download', image)"
                class="cursor-pointer download-icon"
              ></DownloadIcon>
              <BsTooltip anchor="top middle" self="bottom middle" class="arrow-bottom">
                {{ $t('tooltip_download_image') }}
              </BsTooltip>
            </BsButton>
            <BsButton name="close-icon">
              <q-icon
                size="24px"
                name="close"
                style="cursor: pointer"
                @click="showImage = false"
              ></q-icon>
            </BsButton>
          </div>
          <img :src="image" alt="generated image" class="generated-image-preview" />
      </q-card>
    </q-dialog>
    <q-icon
      :name="`img:${closeOutline}`"
      class="cursor-pointer file-preview-close"
      @click="emits('delete')"
      size="xs"
      v-if="removable"
    />
  </div>
</template>

<script setup lang="ts">
import { onMounted, toRefs } from 'vue'
import { computed } from 'vue'
import closeOutline from '@/assets/icons/close-outline.svg'
import { ref } from 'vue'
import DownloadIcon from './icons/DownloadIcon.vue'
import { ServerApi } from '@/api/server_api'
import { ResponseStatus } from '@/models'
import imagePlaceholder from '@/assets/images/placeholder-image.webp'
const props = defineProps<{
  uploadedImage?: string
  height?: string
  width?: string
  removable?: boolean
  downloadable?: boolean
  filePath?: string
  deleted?: boolean
}>()
const emits = defineEmits(['loaded', 'delete', 'download', 'loaded-file'])
const { uploadedImage, height, width, downloadable, filePath } = toRefs(props)
const showImage = ref(false)
const placeholder = imagePlaceholder
const imageSrc = ref(placeholder)
const imgStyle = computed(() => ({
  maxHeight: height?.value ?? '70px',
  maxWidth: width?.value ?? '100px',
  cursor: downloadable.value ? 'pointer' : 'default',
  minHeight: height?.value ?? '70px',
  minWidth: width?.value ?? '100px'
}))

const image = computed(() => {
  return filePath?.value ? imageSrc.value : uploadedImage?.value
})
const fetchImage = async () => {
  if (filePath?.value) {
    const response = await ServerApi.loadImage(filePath.value)
    if (response.status === ResponseStatus.OK) {
      imageSrc.value = response.data.file_data
      emits('loaded-file', imageSrc)
    }
  }
}
onMounted(() => {
  fetchImage()
})
</script>
<style>
.file-preview {
  display: inline;
}
.file-preview-close {
  position: absolute;
  top: 4px;
}
.generated-image-preview {
  padding: 8px;
  padding-top: 0;
}
.q-card.file-preview-card {
  max-width: 90vw;
  max-height: 90vh;
  padding-top: 4px;
}
@media screen and (orientation: landscape) and (max-height: 600px) and (max-width: 1000px),
  (max-width: 600px) {
  .generated-image-preview {
    width: 100%;
    /* height: 100%; */
  }
}
</style>
