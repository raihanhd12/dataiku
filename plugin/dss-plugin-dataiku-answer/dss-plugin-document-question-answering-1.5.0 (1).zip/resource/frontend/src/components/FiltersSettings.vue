<template>
  <div v-if="setup.filtersConfig">
    <div class="row items-center no-wrap q-gutter-x-sm" style="margin-top: 20px">
      <div class="bs-font-medium-4-semi-bold">{{ t('filters') }}</div>
    </div>
    <div style="overflow-y: scroll" v-if="Object.keys(setup.filtersConfig.filter_options).length">
      <BSMultiSelect
        v-for="(options, column) in setup.filtersConfig.filter_options"
        :key="column"
        :label="t('select_label', { item: column })"
        :all-options="options"
        :model-value="filters[column]"
        @update:modelValue="(newVal) => $emit('update:settings', column, newVal)"
      >
      </BSMultiSelect>
    </div>
    <BsWarning type="info" :text="t('empty_filters_text')" v-else> </BsWarning>
  </div>
</template>
<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import BsWarning from './BsWarning.vue'
import BSMultiSelect from './BsMultiSelect.vue'
import { useUI } from './composables/use-ui'
const { t } = useI18n()
const { setup } = useUI()
defineProps<{
  filters: any
}>()
defineEmits<{
  (e: 'update:settings', column: string, newVal: string[]): void
}>()
</script>
