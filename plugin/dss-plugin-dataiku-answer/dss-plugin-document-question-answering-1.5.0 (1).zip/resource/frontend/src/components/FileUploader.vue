<template>
  <div style="display: inline-block">
    <q-btn
      id="select-files-btn"
      flat
      dense
      color="primary"
      @click="triggerFileInput"
      no-caps
      class="bs-font-medium-3-normal choose-files-btn"
    >
      {{ t('select_files') }}<span class="show-on-mobile">&nbsp;{{ t('files_and_images') }}</span>
    </q-btn>
    <input
      type="file"
      ref="fileInput"
      id="file-input"
      @change="handleFileChange"
      :accept="uploadFileTypes"
      multiple
      style="display: none"
    />
  </div>
</template>

<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { ref } from 'vue'

const { t } = useI18n()
defineProps<{
  uploadFileTypes?: string
}>()

const emits = defineEmits(['update:status', 'uploadFile', 'updateSelectedFiles'])

const fileInput = ref<HTMLInputElement | null>(null)

const triggerFileInput = () => {
  fileInput.value?.click()
}

const handleFileChange = async (event: Event) => {
  emits('uploadFile', event)
}

const clearFileInput = () => {
  if (fileInput.value) {
    fileInput.value.value = ''
  }
}

// Expose the clearFileInput method
defineExpose({
  clearFileInput
})
</script>

<style scoped lang="scss">
.choose-files-btn {
  padding: 3px;
  margin-top: -3px;
}
</style>
