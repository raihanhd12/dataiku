<template>
  <q-card class="file-drop-zone" @drop.prevent="handleDrop" id="file-dropzone">
    <div>
      <q-icon
        :name="`img:${closeOutline}`"
        class="cursor-pointer delete-file-icon close-drop-zone-icon"
        @click="closeDropZone"
        size="sm"
      />
      <div class="drop-hint" v-if="!selectedFiles.length">
        <span class="hide-on-mobile">
          {{ t('drop_zone') }}
        </span>

        <FileUploader
          id="user-input-file-uploader"
          class="select-icon"
          :upload-file-types="uploadFileTypes"
          @uploadFile="handleFileSelect"
        />

        <div class="supported-files">{{ t('supported_files') }}: {{ fileExtensions }}</div>
      </div>
      <div class="card-container" v-else>
        <div v-for="(file, index) in selectedFiles" :key="index" class="card selected-file">
          <div class="file-icon-container">
            <div class="file-icon">
              <FileIcon></FileIcon>
            </div>
          </div>

          <div>
            <div :title="file.name" class="ellipsized-text">{{ file.name }}</div>
            <div :title="file.type" class="ellipsized-text bs-font-medium-1-semi-bold">
              {{ getFileType(file.type) }}
            </div>
          </div>

          <q-icon
            :name="`img:${closeOutline}`"
            class="cursor-pointer delete-file-icon"
            @click="() => removeFile(index)"
            size="18px"
          />
        </div>
        <FileUploader
          id="user-input-file-uploader"
          class="select-icon"
          :upload-file-types="uploadFileTypes"
          @uploadFile="handleFileSelect"
          v-if="selectedFiles.length < maxNUploadFiles"
        >
        </FileUploader>
      </div>
    </div>
  </q-card>
</template>

<script lang="ts" setup>
import { computed, ref, watch } from 'vue'
import { createNotification } from '@/common/utils'
import { useI18n } from 'vue-i18n'
import { useUI } from '@/components/composables/use-ui'
import FileUploader from '@/components/FileUploader.vue'
import closeOutline from '@/assets/icons/close-outline.svg'
import FileIcon from './icons/FileIcon.vue'
import { type MediaSummary, UploadableFileExtensions, BLACKLISTED_MIME_TYPES } from '@/models'

type nullCheck = null | undefined

const { setup } = useUI()

const props = defineProps<{
  uploadFileTypes?: string
  modelValue: File[]
  uploadedFiles?: MediaSummary[]
}>()

const { t } = useI18n()
const emits = defineEmits(['update:status', 'uploadFile', 'showFileDropZone', 'update:modelValue'])

const selectedFiles = ref<File[]>([])
// const sendIcon = ref<HTMLButtonElement | null>(null)

watch(
  selectedFiles,
  (newFiles) => {
    emits('update:modelValue', newFiles)
  },
  { deep: true }
)

const closeDropZone = () => {
  selectedFiles.value = []
  emits('showFileDropZone', false)
  emits('update:modelValue', [])
}

const getFileType = (fileType: string) => {
  const typeParts = fileType.split('/')
  return typeParts[1] || ''
}

const removeFile = (fileIndex: number) => {
  selectedFiles.value = selectedFiles.value.filter((selectedFile, index) => index !== fileIndex)
}

const fileExtensions = computed(() => {
  if (!props.uploadFileTypes) {
    return ''
  }
  return UploadableFileExtensions
})
const maxUploadSizeMB = computed(() => {
  return setup.value.maxUploadSizeMB ?? 15
})

const maxNUploadFiles = computed(() => {
  return (setup.value.maxNUploadFiles ?? 5) - (props.uploadedFiles?.length ?? 0)
})

function handleDrop(event: DragEvent) {
  event.preventDefault()
  emits('showFileDropZone', true)

  const targetFiles = event.dataTransfer?.files
  validateAndUpdateFileList(targetFiles)
}

function handleFileSelect(event: Event) {
  const target = event.target as HTMLInputElement
  const targetFiles = target.files

  validateAndUpdateFileList(targetFiles)
}
const getFileExtension = (fileName: string) => {
  return fileName.split('.').pop()?.toLowerCase() ?? ''
}
const validateAndUpdateFileList = (files: FileList | nullCheck) => {
  if (!files?.length) {
    console.error('No files detected on drop.')
    return
  }
  if (files.length > maxNUploadFiles.value) {
    emits('update:status', {
      type: 'error',
      msg: 'too_many_files'
    })
    createNotification(
      'negative',
      t('too_many_files', { maxNUploadFiles: maxNUploadFiles.value })
    )
    return
  }
  const previouslySelectedFilesMap = new Set(selectedFiles.value.map((file) => file.name))
  // Handle uploaded files in current conversation
  for (const file of props.uploadedFiles ?? []) {
    previouslySelectedFilesMap.add(file.original_file_name ?? '')
  }
  let notified = false
  for (let i = 0; i < files.length; i++) {
    const file = files[i]
    // / Check if MIME type is explicitly allowed
    const isMimeTypeAllowed = file.type && props.uploadFileTypes?.includes(file.type)
    // Fallback to handle issues detecting the right mimetype: Check if MIME type is blacklisted or extension is invalid
    const fileExtension = getFileExtension(file.name)
    const isMimeTypeBlacklisted = file.type && BLACKLISTED_MIME_TYPES.includes(file.type)
    const isFileExtensionValid = fileExtensions.value.includes(fileExtension)
    if (
      !isMimeTypeAllowed &&
      (isMimeTypeBlacklisted || !isFileExtensionValid) // MIME is blacklisted or extension is invalid
    ) {
      // Validate file type
      emits('update:status', {
        type: 'error',
        msg: 'invalid_file_type'
      })
      createNotification('negative', t('invalid_file_type'))
      return
    }
    if (file.size > maxUploadSizeMB.value * 1048576) {
      // Validate file size
      emits('update:status', { type: 'error', msg: 'file_too_large' })
      createNotification('negative', t('file_too_large', { size: maxUploadSizeMB.value }))
      return
    }
    if (file.name === 'image.jpg' && file.type.startsWith('image/')) {
      // Generate a unique name for the photo taken from the camera
      const timestamp = Date.now()
      const uniqueName = `photo_${timestamp}_${i}.jpg`
      selectedFiles.value.push(new File([file], uniqueName, { type: file.type }))
    } else {
      if (previouslySelectedFilesMap.has(file.name) && !notified) {
        // Notify user about duplicate files only once
        createNotification('negative', t('duplicate_files'))
        notified = true
      } else if (!previouslySelectedFilesMap.has(file.name)) {
        selectedFiles.value.push(file)
      }
    }
  }
}
</script>

<style scoped>
.file-drop-zone {
  padding: 10px;
  text-align: center;
  transition: background-color 0.3s;
  background: var(--bg-examples-brand-hover);
  box-shadow: none;
}
.drop-hint {
  color: var(--brand);
}

.card-container {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-start;
  align-items: center;
}

.card {
  display: flex;
  gap: 5px;
  align-items: center;
  position: relative;
  width: auto;
  height: 60px;
  min-width: 60px;
  padding: 5px;
  font-size: 12px;
  background-color: #fff;
  box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  text-align: left;
  transition: transform 0.3s ease;
}

.card:hover {
  transform: scale(0.9);
}

.delete-file-icon {
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  right: -7px;
  top: -7px;
  padding: 3px;
}
.conversation-type-toggle {
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  bottom: 0;
  right: 25px;
  padding: 3px;
}
.conversation-toggle-thumb ::v-deep .q-toggle__thumb {
  color: var(--brand);
}
.conversation-toggle-thumb ::v-deep .q-toggle__track {
  background-color: var(--brand);
}
.ellipsized-text {
  max-width: 230px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}

.supported-files {
  display: block;
  font-size: 11px;
}
.file-icon {
  width: 15px;
  height: 15px;
}

.file-icon-container {
  padding: 3px 2px;
  background-color: var(--bg-examples-borders);
  border-radius: 3px;
}

.close-drop-zone-icon {
  position: absolute;
  right: 8px;
  top: 2px;
  color: var(--brand);
}
.send-icon {
  transform: rotate(-38.48deg);
}
.file-upload-button {
  border: none;
  background: none;
  position: absolute;
  right: 4px;
  color: var(--brand);
  padding-bottom: 8px;
  bottom: 5px;
}
</style>
