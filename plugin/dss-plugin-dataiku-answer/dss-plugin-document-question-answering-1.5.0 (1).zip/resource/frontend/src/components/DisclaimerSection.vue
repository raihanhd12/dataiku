<template>
  <div class="dku-tiny-text disclaimer" id="disclaimer">
    <div v-html="disclaimerText"></div>
  </div>
</template>
<script lang="ts" setup>
import { computed } from 'vue'
import { useUI } from '@/components/composables/use-ui'
import DOMPurify from 'dompurify'
const disclaimerText = computed(() => {
  return DOMPurify.sanitize(useUI().setup.value.disclaimer || '')
})
</script>
