from backend.utils.dataiku_api import dataiku_api
from dataiku.langchain.dku_llm import DKULLM


class LLM_API_Setup:
    def __init__(self, dataiku_api):
        self.dataiku_api = dataiku_api
        self.llm = self.dataiku_api.webapp_config.get("llm_id")
        self.max_tokens = self.dataiku_api.webapp_config.get("max_llm_tokens")

    def get_llm(self):
        llm_id = self.dataiku_api.webapp_config.get("llm_id")
        if not llm_id:
            raise ValueError("A Dataiku LLM ID must be provided")
        self.llm = DKULLM(llm_id=llm_id, max_tokens=self.max_tokens)
        return self.llm


llm_setup = LLM_API_Setup(dataiku_api)
