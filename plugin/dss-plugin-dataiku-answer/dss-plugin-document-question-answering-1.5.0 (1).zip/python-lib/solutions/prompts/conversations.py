from langchain_core.prompts import ChatPromptTemplate

MEDIA_QA_CONVERSATION_TITLE_PROMPT = """You are an expert in generating accurate conversations titles. Given a list of summaries regarding documents or images which are about to be discussed you generate a conversation title that is concise.

Conditions:
- Don't write a title that contains more than 6 words.
- Generate directly the title without any further explanations, decorations or any additional text
- Use the same language as the summaries. If the language is not clear use English.

{media_summaries}
"""


# Condensation
condensation_system = "You are an expert in analyzing and refining user interactions to craft precise and context-aware queries. Your main task is to synthesize the user's conversational history into a single, coherent query. This involves capturing the essence of the most recent relevant topic discussed, and only incorporating earlier topics if they directly relate to the most recent one and remain unresolved. Your task is NEVER to actually answer user's query, but to rephrase it so that it synthesizes the history. If the latest input is a terminal statement, such as 'thank you' or 'it worked, this is helpful', you should mirror this input exactly as your response, indicating no further action is needed. Ensure that your response succinctly encapsulates the critical aspects of the user's needs without any additional commentary or extraneous information."

condensation_input = """Based on the following  ### CHAT HISTORY and  ### LATEST USER INPUT, focus on the last relevant topic and condense the conversation into a single query. Ensure the query is directly derived from the latest significant interaction or reflects terminal statements as needed.
    # CHAT HISTORY
    
    {chat_history_str}

    # END OF CHAT HISTORY

    # LATEST USER INPUT:

    {last_user_input}
    
    # END OF LATEST USER INPUT

    # Stand-alone sentence:
    """


class ChatHistoryHandler:
    def __init__(self):
        self.prompt = ChatPromptTemplate.from_messages([("system", condensation_system), ("user", condensation_input)])

    def format_chat_history(self, chat_history: list, dialogs_format: str = "input_output_dictionaries"):
        """
        Formats a chat history as a string for condensation

        :param: chat_history: list: The chat history containing dialog turns.
        :param: dialogs_format: str: The format of the chat dialogs. Allowed values are:
            - 'input_output_dictionaries': if the 'chat_history' contains dictionaries with 'input' and 'output'.
                Example: [{'input': 'What is the capital of Germany?', 'output': 'The capital of Germany is Berlin.'}]
            - 'tuples' if  the 'chat_history' contains tuples:
                Example: [('What is the capital of Germany?', 'The capital of Germany is Berlin.')]

        """
        chat_history_string = []
        for dialog_turn in chat_history:
            if dialogs_format == "input_output_dictionaries":
                human_input = dialog_turn["input"]
                ai_input = dialog_turn["output"]
            elif dialogs_format == "tuples":
                human_input = dialog_turn[0]
                ai_input = dialog_turn[1]
            chat_history_string.append(f"""HumanMessage(content="{human_input}"), AIMessage(content="{ai_input}")""")
        return "[" + ", ".join(chat_history_string) + "]"
