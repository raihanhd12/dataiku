from datetime import datetime
from typing import List

from backend.db.conversation import CONVERSATION_DEFAULT_NAME
from backend.models.base import MediaSummary
from backend.utils.context_utils import TIME_FORMAT, LLMStepMetrics, LLMStepName
from backend.utils.dataiku_api import dataiku_api
from backend.utils.llm_utils import separator_length
from dataiku.langchain.dku_llm import DKULLM
from llm_assist.llm_api_handler import llm_setup
from llm_assist.logging import logger
from solutions.chains.conversation_title import ConversationTitleChainHandler
from solutions.mesh.llm import AnswersDSSLLM, CompletionResponse
from solutions.prompts.conversations import MEDIA_QA_CONVERSATION_TITLE_PROMPT


class SummaryTitler(ConversationTitleChainHandler):
    def __init__(self, llm: DKULLM) -> None:
        super().__init__(MEDIA_QA_CONVERSATION_TITLE_PROMPT)
        self.llm = llm
        self.media_conversation_title_prompt = self.get_prompt(llm_setup.get_llm())

    def list_summaries(self, summaries: List[MediaSummary]) -> str:
        folder = dataiku_api.folder_handle
        all_summaries = ""
        if len(summaries) < 1:
            raise Exception("No media summaries found.")
        all_summaries += f"""
            {'-'*separator_length} START OF SUMMARIES {'-'*separator_length}
            """
        for media_summary in summaries:
            original_file_name = media_summary.get("original_file_name", "")
            topics = media_summary.get("topics", [])
            metadata_path = media_summary.get("metadata_path")
            if not metadata_path:
                logger.error(f"metadata_path is not provided for document {original_file_name}")
                raise Exception(f"metadata_path is not provided for document {original_file_name}")
            extract_summary = folder.read_json(metadata_path)
            summary_text = extract_summary.get("summary", "")
            all_summaries += f"""
            File: {original_file_name}
            Topics: {topics}
            Summary: {summary_text}
            {'-'*separator_length}
            """
        all_summaries += f"{'-'*separator_length} END OF SUMMARIES {'-'*separator_length}"
        return all_summaries

    def generate_summary_title(self, summaries: List[MediaSummary]) -> str:
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        media_summaries: str = self.list_summaries(summaries)
        prompt_message = self.media_conversation_title_prompt\
                    .invoke(dict(media_summaries=media_summaries))\
                    .to_string()
        llm_id = dataiku_api.webapp_config.get("title_llm_id", None) or self.llm.llm_id
        logger.debug(f"Using LLM ID for title generation: {llm_id}")
        completion = AnswersDSSLLM(llm_id).new_completion()
        completion.with_message(prompt_message)
        current_step = LLMStepMetrics(step_name=LLMStepName.SUMMARY_TITLE.value, step_start_time=start_time)
        conversation_title = CONVERSATION_DEFAULT_NAME
        try:
            resp: CompletionResponse = completion.execute(current_step)
            conversation_title = str(resp.text)
            if not conversation_title and resp.errorMessage:
                raise Exception(resp.errorMessage)
        except Exception as e:
            logger.exception(f"Error when calling LLM API: {e}.")
            raise Exception(f"Error when calling LLM API: {e}.")
        logger.debug(f"conversation_title; {conversation_title}")
        return conversation_title

