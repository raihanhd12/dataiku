from typing import Any, Dict, List, Optional

from backend.models.base import LlmHistory, MediaSummary
from backend.utils.context_utils import LLMStepName
from backend.utils.dataiku_api import dataiku_api
from dataiku.langchain.dku_llm import DKULLM
from solutions.chains.generic_decision_chain import GenericDecisionJSONChain
from solutions.prompts.conversations import ChatHistoryHandler


class SelfServiceDecisionChain(GenericDecisionJSONChain):
    def __init__(self, llm: DKULLM, user_query: str, chat_history: List[LlmHistory], media_summaries: List[MediaSummary]) -> None:
        self._llm = llm
        chat_history_str = self.__handle_chat_history(chat_history)
        formatted_summaries = self.format_summaries(media_summaries)

        self._prompt = (
            "# Role and Guidelines:\n"
            "Examine the human query, the chat history and document summaries to determine if the human query requires additional information from any or all of the documents to answer the question. \n"
            "You should never try to answer the human query. You only select documents and explain why you selected them. \n"
            "if additional information is needed then select the documents by their title and give a justification for your selection. \n\n"
            "Your answer must be in the form of a JSON object with two keys: \n"
            "- 'justification': why you chose to select the documents you selected or chose not to select any. \n"
            "- 'documents': List of the titles of the documents you selected. \n\n"
            "If no additional information is needed, provide a justification explaining why no additional information is required. In this case, 'documents' should be an empty list. \n"
            "# Rules:\n"
            "1 - Return only a JSON object with 2 keys: 'justification' and 'documents'. \n"
            "2 - Provide only the JSON object. Do not include any other explanations, decorations, or additional information. \n"
            "3 - Ensure the JSON object is in a format that can be parsed directly by a JSON parser without needing any preprocessing. Use double quotes for keys and string values. \n"
            "4 - Do not attempt to answer the human query. \n"
            "5 - If no additional information is needed, 'documents' should be an empty list. \n"
            "6 - Greetings and thanks do not require any additional information so no documents should be selected. \n"
            "7 - If the human query asks about specific details, relationships, or content that cannot be fully addressed by the summaries alone, or if the query is open-ended but likely pertains to the provided documents, you should select the relevant documents. \n"
            "8 - If the human query is vague or lacks specific details but could reasonably be interpreted as referring to the provided documents, assume the human wants to use the documents in context and select all relevant documents. \n"

            "# CONTEXT:\n"
            "## Summaries:\n"
            f"{formatted_summaries}\n"
            "--- END OF SUMMARIES ---\n"
            "## Chat History"
            f"{chat_history_str}\n"
            "--- END OF CHAT HISTORY ---\n"
            f"Human: {user_query}\n"
        )

    def get_doc_summary(self, metadata_path: str) -> str:
        folder = dataiku_api.folder_handle
        if metadata := folder.read_json(metadata_path):
            return str(metadata.get("summary", ""))
        return ""

    def format_summaries(self, media_summaries: List[MediaSummary]) -> str:
        formatted_summaries = ""
        for summary in media_summaries:
            original_title = summary.get("original_file_name", "")
            metadata_path = summary.get("metadata_path", "")
            doc_summary = self.get_doc_summary(metadata_path)
            formatted_summaries += f"### Document Title:  {original_title}\n"
            formatted_summaries += f"{doc_summary}\n"
            formatted_summaries += "----------------------------------\n"
        return formatted_summaries

    @property
    def prompt(self):
        return self._prompt

    @property
    def llm(self) -> DKULLM:
        return self._llm

    @property
    def chain_purpose(self) -> str:
        return LLMStepName.DECISION_SELF_SERVICE.value

    def verified_json_output(self, json_output) -> Dict[str, Any]:
        documents: Optional[List[str]] = json_output.get("documents")
        justification: Optional[str] = json_output.get("justification")
        if not documents:
            return {
                "decision": False,
                "justification": justification,
                "documents": [],
            }

        return {
            "decision": True,
            "justification": justification,
            "documents": documents,
        }

    def __handle_chat_history(self, chat_history: List[LlmHistory]):
        chat_history_str = None
        chat_history_handler = ChatHistoryHandler()
        chat_history_str = chat_history_handler.format_chat_history(chat_history=chat_history)
        return chat_history_str
