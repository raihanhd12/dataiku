import json
import time
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union

from backend.models.base import ConversationParams, LlmHistory, LLMStep, MediaSummary
from backend.utils.context_utils import TIME_FORMAT, LLMStepMetrics, LLMStepName
from backend.utils.dataiku_api import dataiku_api
from backend.utils.llm_utils import append_summaries_to_completion_msg, get_llm_capabilities
from dataiku.langchain.dku_llm import DKULLM
from dataikuapi.dss.llm import DSSLLMCompletionQueryMultipartMessage
from langchain.memory import ConversationBufferMemory
from langchain_core.prompt_values import PromptValue
from llm_assist.logging import logger
from solutions.mesh.llm import AnswersDSSLLM, AnswersDSSLLMCompletionQuery, CompletionResponse


class GenericAnswersChain(ABC):
    # Abstract class for Answers chains
    # Implement all abstract properties & methods in the child class
    @property
    def webapp_config(self):
        return dataiku_api.webapp_config

    @property
    @abstractmethod
    def qa_chain(self) -> Any:
        raise NotImplementedError("Subclasses must implement qa_chain property")

    @property
    @abstractmethod
    def act_like_prompt(self) -> str:
        raise NotImplementedError("Subclasses must implement act_like_prompt property")

    @property
    @abstractmethod
    def system_prompt(self) -> str:
        raise NotImplementedError("Subclasses must implement system_prompt property")

    @property
    @abstractmethod
    def llm(self) -> DKULLM:
        raise NotImplementedError("Subclasses must implement llm property")

    @property
    @abstractmethod
    def computed_prompt(self) -> PromptValue:
        raise NotImplementedError("Subclasses must implement computed_prompt property")

    @property
    @abstractmethod
    def chain_purpose(self) -> str:
        raise NotImplementedError("Subclasses must implement chain_purpose property")

    @abstractmethod
    def load_role_and_guidelines_prompts(self, params: ConversationParams):
        raise NotImplementedError("Subclasses must implement load_role_and_guidelines_prompts method")

    @abstractmethod
    def create_chain(self, params: ConversationParams) -> Any:
        raise NotImplementedError("Subclasses must implement create_chain method")

    def prepare_qa_chain(self, params: ConversationParams) -> None:
        self.load_role_and_guidelines_prompts(params)
        self.create_chain(params)

    @abstractmethod
    def get_computing_prompt_step(self, params: ConversationParams) -> LLMStep:
        raise NotImplementedError("Subclasses must implement get_computing_prompt_step method")

    @abstractmethod
    def get_querying_step(self, params: ConversationParams) -> LLMStep:
        raise NotImplementedError("Subclasses must implement get_querying_step method")

    @abstractmethod
    def finalize_streaming(
        self, params: ConversationParams, question_context: Union[str, Dict[str, Any], List[str]]
    ) -> Optional[Dict[str, Any]]:
        raise NotImplementedError("Subclasses must implement finalize_streaming method")

    @abstractmethod
    def finalize_non_streaming(
        self, params: ConversationParams, question_context: Union[str, Dict[str, Any], List[str]]
    ) -> Dict[str, Any]:
        raise NotImplementedError("Subclasses must implement finalize_non_streaming method")

    @abstractmethod
    def create_computed_prompt(
        self,
        params: ConversationParams,
    ) -> Tuple[PromptValue, Dict[str, Any]]:
        raise NotImplementedError("Subclasses must implement create_computed_prompt method")

    @abstractmethod
    def get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any], List[str]],
        user_profile: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        logger.error("get_as_json method not implemented")
        return {}

    @abstractmethod
    def create_query_from_history_and_update_params(
        self, chat_history: List[LlmHistory], user_query: str, params: ConversationParams
    ) -> ConversationParams:
        return params

    def __run_non_streaming_query(
        self,
        params: ConversationParams,
        completion: AnswersDSSLLMCompletionQuery,
        question_context: Dict[str, Any],
    ):
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        global_start_time = params.get("global_start_time")
        if not global_start_time:
            raise Exception("global_start_time is not provided")
        response = ""
        step = self.get_querying_step(params)
        logger.debug({"step": step.name})
        yield {"step": step}
        try:
            chain_purpose: str = params.get("chain_purpose") or LLMStepName.UNKNOWN.value
            current_step = LLMStepMetrics(step_name=chain_purpose, step_start_time=start_time)
            resp: CompletionResponse = completion.execute(current_step)
            response = str(resp.text)
            if not resp.text and resp.errorMessage:
                response = resp.errorMessage
            logger.debug(f"""Time ===> taken by getting first chunk: {round((datetime.now() - datetime.strptime(start_time, TIME_FORMAT)).total_seconds(), 2)} secs
            Time ===> GLOBAL taken by getting first chunk: {(time.time() - global_start_time):.2f} secs
            """)

        except Exception as e:
            msg = "Error when calling LLM API"
            logger.exception(f"{msg}: {e}.")
            result = self.finalize_streaming(params, msg)
            yield result

        question_context["answer"] = response
        yield self.finalize_non_streaming(params, question_context)

    def __run_streaming_query(
        self, params: ConversationParams, completion: AnswersDSSLLMCompletionQuery, question_context: Dict[str, Any]
    ):
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        global_start_time = params.get("global_start_time")
        if not global_start_time:
            raise Exception("global_start_time is not provided")
        log_time = True
        try:
            chain_purpose: str = params.get("chain_purpose") or LLMStepName.UNKNOWN.value
            current_step = LLMStepMetrics(step_name=chain_purpose, step_start_time=start_time)
            for chunk in completion.execute_streamed(current_step):
                yield chunk
                if log_time:
                    if global_start_time:
                        logger.debug(f"""Time ===> taken by getting first chunk: {round((datetime.now() - datetime.strptime(start_time, TIME_FORMAT)).total_seconds(), 2)} secs
                        Time ===> GLOBAL taken by getting first chunk: {(time.time() - global_start_time):.2f} secs""")
                    else:
                        logger.debug(
                            f"Time ===> taken by getting first chunk: {round((datetime.now() - datetime.strptime(start_time, TIME_FORMAT)).total_seconds(), 2)} secs"
                        )
                    log_time = False
            yield {"step": LLMStep.STREAMING_END}
            result = self.finalize_streaming(params, question_context)
            if result:
                yield result
        except Exception as e:
            msg = "Error when calling LLM API"
            logger.error(f"{msg}: {e}.")
            result = self.finalize_streaming(params, msg)
            yield result

    def __create_completion_query(
        self,
        computed_prompt: PromptValue,
        params: ConversationParams,
    ) -> AnswersDSSLLMCompletionQuery:
        media_summaries: List[MediaSummary] = params.get("media_summaries") or []
        previous_media_summaries: List[MediaSummary] = params.get("previous_media_summaries") or []
        summaries = media_summaries or previous_media_summaries
        completion: AnswersDSSLLMCompletionQuery = AnswersDSSLLM(self.llm.llm_id).new_completion()
        completion.with_message(computed_prompt.to_string(), role="system")
        if summaries:
            msg: DSSLLMCompletionQueryMultipartMessage = completion.new_multipart_message(role="user")
            msg.with_text(computed_prompt.to_string())
            # Commented this code for now as we don't always have summaries so the decision chain would need change
            # Later it can be used in other chains as well
            # selected_titles: List[str]
            # if self_service_decision := params.get("self_service_decision"):
            #     documents = self_service_decision.get("documents")
            #     selected_titles = documents if isinstance(documents, list) else []
            #     selected_summaries = [s for s in media_summaries if s.get("original_file_name") in selected_titles]
            # else:
            #     logger.warn("No self service decision provided")
            selected_summaries = summaries 
            append_summaries_to_completion_msg(selected_summaries, msg)
        completion.with_message(params.get("user_query", ""), role="user")
        return completion

    def format_history(self, chat_history: List[LlmHistory]):
        return [(item["input"], item["output"]) for item in chat_history]

    def run_completion_query(self, params: ConversationParams, memory: ConversationBufferMemory):
        self.memory = memory
        self.prepare_qa_chain(params)

        yield {"step": self.get_computing_prompt_step(params)}

        computed_prompt, question_context = self.create_computed_prompt(params)

        completion = self.__create_completion_query(computed_prompt, params)

        llm_capabilities = get_llm_capabilities()
        if llm_capabilities["streaming"]:
            yield from self.__run_streaming_query(
                params=params,
                completion=completion,
                question_context=question_context,
            )
        else:
            yield from self.__run_non_streaming_query(
                params=params, completion=completion, question_context=question_context
            )

    def load_default_role_and_guidelines_prompts(self) -> tuple:
        act_like_prompt = dataiku_api.webapp_config.get("primer_prompt", "")
        system_prompt = dataiku_api.webapp_config.get(
            "system_prompt",
            "The following is a friendly conversation between a human and an AI. The AI is talkative and provides lots of specific details from its context. If the AI does not know the answer to a question, it truthfully says it does not know.",
        )
        return act_like_prompt, system_prompt

    def append_user_profile_to_prompt(
        self, system_prompt: str, user_profile: Optional[Dict[str, Any]] = None, include_full_user_profile: bool = True
    ) -> str:
        if user_profile:
            if language := user_profile.get("language", {}).get("value"):
                system_prompt += (
                    "The human prefers to communicate in "
                    + str(language)
                    + ". Adjust your answer accordingly. Do not mention this."
                )
            else:
                system_prompt += (
                    "The human has not provided a preferred language. Please use English. Do not mention this."
                )
        if user_profile and include_full_user_profile:
            user_profile_without_language = {k: v for k, v in user_profile.items() if k != "language"}
            user_profile_json = json.dumps(user_profile_without_language).replace("{", "{{").replace("}", "}}")
            system_prompt = f"{system_prompt}. \n The user profile is the following: \n # USER PROFILE: \n {user_profile_json} \n # --- END OF USER PROFILE ---\n Consider information provided in the USER PROFILE if meaningful, take it into account."
        return system_prompt
