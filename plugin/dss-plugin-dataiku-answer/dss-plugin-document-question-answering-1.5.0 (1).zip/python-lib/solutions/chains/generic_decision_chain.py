
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict

from backend.db.sql.sql_timing import log_query_time
from backend.utils.context_utils import TIME_FORMAT, LLMStepMetrics, LLMStepName
from backend.utils.dataiku_api import dataiku_api
from backend.utils.json_utils import extract_json
from llm_assist.logging import logger
from solutions.mesh.llm import AnswersDSSLLM, CompletionResponse


class GenericDecisionJSONChain(ABC):
    # Abstract class for Decision Chain that returns JSON objects
    # Implement the prompt property in the child class
    @property
    @abstractmethod
    # The prompt that will be used to generate the decision
    # This should instruct the model on what decision to make
    # and what information to include in the decision
    # This should instruct the model to output JSON!!!!
    def prompt(self):
        raise NotImplementedError("Subclasses must implement prompt property")

    @property
    @abstractmethod
    def llm(self):
        raise NotImplementedError("Subclasses must implement llm property")

    @property
    @abstractmethod
    def chain_purpose(self) -> str:
        raise NotImplementedError("Subclasses must implement chain_purpose property")


    @abstractmethod
    def verified_json_output(self, json_output: Dict[str, Any]) -> Dict[str, Any]:
        pass
    @log_query_time
    def get_decision_as_json(self, user_query: str, step_name: str = LLMStepName.UNKNOWN.value) -> Dict[str, Any]:
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        if self.prompt is None:
            logger.error("Prompt is not defined")
            return {}
        logger.debug(f"{self.chain_purpose} Final Prompt: {self.prompt}")
        llm_id = dataiku_api.webapp_config.get("json_decision_llm_id", None) or self.llm.llm_id
        logger.debug(f"Using LLM ID for decision chain in json format: {llm_id}")
        completion = AnswersDSSLLM(llm_id).new_completion()

        try:
            current_step = LLMStepMetrics(step_name=step_name, step_start_time=start_time)
            completion.with_message(self.prompt, role="system")
            completion.with_message(user_query, role="user")
            llm_response: CompletionResponse = completion.execute(current_step)
            response = llm_response.text
            logger.debug(f"{self.chain_purpose} llm response: '{response}'")
            if not response and llm_response.errorMessage:
                raise Exception(llm_response.errorMessage)
            if not response:
                raise Exception("Error occurred during completion")

            if isinstance(response, dict):
                json_response = response
            else:
                json_response = extract_json(response)

            logger.debug(f"Extracted response  {json_response}")
            verified_resp = self.verified_json_output(json_response)
            return verified_resp
        except Exception as e:
            logger.error(f"{self.chain_purpose} completion call failed: {llm_response.errorMessage}")
            logger.error(f"Failed to parse LLM response for query '{user_query}'. Exception: {e}", exc_info=True)
            return {}
