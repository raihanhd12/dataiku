import json
import re
from typing import List, Optional, Tuple

from backend.db.sql.sql_timing import log_query_time
from backend.models.base import MediaSummary
from backend.utils.context_utils import LLMStepMetrics, LLMStepName
from backend.utils.llm_utils import load_pdf_images_from_file
from dataikuapi.utils import DataikuException
from langchain.chains import ConversationChain
from langchain.prompts import PromptTemplate
from llm_assist.llm_api_handler import llm_setup
from llm_assist.logging import logger
from solutions.mesh.llm import AnswersDSSLLM, CompletionResponse

LLM = llm_setup.get_llm()


@log_query_time
def get_doc_as_image_summary(
    file_path: str, original_file_name: str, language: Optional[str], start_time: str
) -> Tuple[Optional[MediaSummary], Optional[str]]:
    summary = MediaSummary(summary=None, topics=None, questions=None)
    doc_as_image_system_prompt = """
    # Role and Guidelines
    Your role is to look at and summarise the pages of a document provided to you. These pages have been uploaded to a webapp.
    Your summary should mention the contents of each section of the document if possible.
    You should provide your answer in JSON format with the following keys
    - "summary": str: summary of all the pages provided to you
    - "topics": Array[str]: array of all the main topics that appear in the document provided.
    - "questions": Array[str]: array of 3 questions which can be asked based on the document provided to you.
    The JSON object should have double quotes for keys and values. It is important to follow the JSON format strictly.
    Provide a JSON object only. Do not add any other explanations, decorations, or additional information beyond the JSON object.
    """
    doc_as_image_user_prompt = """
    Summarise the following extracted document text
    Your JSON object:
    """
    if language:
        doc_as_image_system_prompt += f"""
    Your response should be in {language}
    """

    template = r"""
        {system_prompt}
        {{history}}
        Human: {{input}}
        Assistant:""".format(system_prompt=doc_as_image_system_prompt)
    qa_prompt = PromptTemplate(input_variables=["input", "history"], template=template)

    qa_chain = ConversationChain(llm=LLM, verbose=True, prompt=qa_prompt)
    computed_prompt = qa_chain.prep_prompts(input_list=[{"input": doc_as_image_user_prompt, "history": ""}])
    prompt = computed_prompt[0][0]

    b64_images: List[str] = load_pdf_images_from_file(file_path)
    n_page: int = len(b64_images)

    completion = AnswersDSSLLM(LLM.llm_id).new_completion()
    msg = completion.new_multipart_message()

    msg.with_text(prompt.to_string())
    for page, img_b64 in enumerate(b64_images):
        msg.with_text(f"{original_file_name}: Page {page+1} of {n_page}").with_inline_image(img_b64)
    msg.add()
    text = ""
    try:
        current_step = LLMStepMetrics(step_name=LLMStepName.DOC_AS_IMAGE_SUMMARY.value, document_name=original_file_name, step_start_time=start_time)
        resp: CompletionResponse = completion.execute(current_step)
        text = str(resp.text)
        if not text and resp.errorMessage:
            return None, resp.errorMessage
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            json_str = match.group(0)
            summary = json.loads(json_str)
            return summary, None
        else:
            msg = f"No JSON object found in the response {text}"
            logger.error(msg)
            raise Exception(text)
    except json.JSONDecodeError as e:
        msg = f"Error decoding JSON during document image summarization: {e}. Response received: {text}"
        logger.exception(msg)
        raise Exception(msg)
    except DataikuException as e:
        msg = f"Dataiku API Error: {e}. "
        logger.exception(msg)
        raise e
    except Exception as e:
        msg = f"Error during document image summarization: {e}. Response received: {text}"
        logger.exception(msg)
        raise e
