from typing import Any, Dict, List, Optional

from backend.models.base import LlmHistory
from backend.utils.context_utils import LLMStepName
from dataiku.langchain.dku_llm import DKULLM
from solutions.chains.generic_decision_chain import GenericDecisionJSONChain
from solutions.prompts.conversations import ChatHistoryHandler


class ImageGenerationDecisionChain(GenericDecisionJSONChain):
    def __init__(self, llm: DKULLM, chat_history: List[LlmHistory], system_prompt: Optional[str]) -> None:
        self._llm = llm
        chat_history_str = self.__handle_chat_history(chat_history)
        system_prompt = system_prompt or ""
        examples = """
            ## Example 1:
            ---  CHAT HISTORY: ---
            [HumanMessage(content="generate blue circle"),
            AIMessage(content='{"generated_media_by_ai": {"images": [{"file_path": "admin_1724677117_04RMXS.png", "file_format": "png", "referred_file_path":""}]}}'),]
            --- END OF CHAT HISTORY ---
            Human: What are the revenues for Q1 2023 and Q2 in 2023?
            Expected Answer: {"query": null, "justification": "Not an image generation query", "referred_image": null}

            ## Example 2:
            ---  CHAT HISTORY: ---
            []
            --- END OF CHAT HISTORY ---

            Human: How are you today?
            Expected Answer: {"query": null, "justification": "Not an image generation query", "referred_image": null}

            ## Example 3:
            ---  CHAT HISTORY: ---
            [HumanMessage(content="hello"),
            AIMessage(content="How can I help you today?")]
            --- END OF CHAT HISTORY ---
            Human: Generate an image with a red circle and a blue square.
            Expected Answer: {"query": "Generate an image with a red circle and a blue square", "justification": "Image generation query", "referred_image": null}

            ## Example 4:
            ---  CHAT HISTORY: ---
            [HumanMessage(content="generate blue circle"),
            AIMessage(content='{"generated_media_by_ai": {"images": [{"file_path":"admin_1724677117_04RMXS.png", "file_format": "png", "referred_file_path":""}]}}')],
            HumanMessage(content="hello"),
            AIMessage(content="Error processing your request"),
            HumanMessage(content="change color to red"),
            AIMessage(content='{"generated_media_by_ai": {"images": [{"file_path":"admin_1724677570_LFUUQS.png", "file_format": "png", "referred_file_path":"admin_1724677117_04RMXS"}]}}')],
            HumanMessage(content="change color to yellow"),
            AIMessage(content='{"generated_media_by_ai": {"images": [{"file_path":"admin_1724677825_B7EGNE.png", "file_format": "png", "referred_file_path":"admin_1724677570_LFUUQS"}]}}')]]
            --- END OF CHAT HISTORY ---
            Human: change to red again
            Expected Answer: {"query": "Generate an image with a red circle", "justification": "Image generation query referring to a previous image in the chat", "referred_image": "admin_1724677825_B7EGNE.png"}
            """

        self._prompt = (
            "Examine the human query and the chat history to determine if an image generation is needed. "
            "Identify if it is a request to generate an image and craft a new query for the image generation AI to perform at best the image generation task. "
            "Image generation AI doesn't have access to chat history. It can only generate images based on the query you generate and an image as reference when needed.\n"
            f"{system_prompt}\n"
            "# INSTRUCTIONS\n"
            "1 - Return only a JSON object with three keys: 'query', 'justification' and 'referred_image'. If no query is needed, 'query' should be null and 'justification' should explain why no query is necessary, same for 'referred_image'.\n"
            "   - 'query': The exact query to generate the desired image, or null if image generation is not needed.\n"
            "   - 'justification': A brief explanation detailing why the query is needed or not.\n"
            "   - 'referred_image': The image's file path that the human is referring to, or null if no image is referred. File path of previously generated images can be found in the chat history in generated_media_by_ai > images > file_path. \n"
            "2 - Provide only the JSON object. Do not include any other explanations, decorations, or additional information.\n"
            "3 - Ensure the JSON object is in a format that can be parsed directly by a JSON parser without needing any preprocessing. Use double quotes for keys and string values.\n"
            "4 - If multiple images could be referenced, choose the most relevant or the most recent one based on the human's query context. The most recent one in the chat history is the closest one to the human query.\n"
            '5 - If no image generation is needed, answer with JSON object: {"query": null, "justification": "your justification for no need for image generation", "referred_image": null}.\n'
            "6 - If the human asks the same query multiple times, you should generate a new image generation query each time without referencing previous images.\n"
            "# EXAMPLES:\n"
            f"{examples}\n"
            "# CONTEXT:\n"
            "## Chat History"
            "--- CHAT HISTORY: ---\n"
            f"{chat_history_str}\n"
            "--- END OF CHAT HISTORY ---\n"
        )

    @property
    def prompt(self):
        return self._prompt

    @property
    def llm(self) -> DKULLM:
        return self._llm

    @property
    def chain_purpose(self) -> str:
        return LLMStepName.DECISION_IMAGE_GENERATION.value

    def verified_json_output(self, json_output) -> Dict[str, Any]:
        if "query" not in json_output or not json_output["query"]:
            return {
                "decision": False,
                "query": None,
                "justification": json_output.get("justification"),
                "referred_image": None,
            }

        return {
            "decision": True,
            "query": json_output.get("query"),
            "justification": json_output.get("justification"),
            "referred_image": json_output.get("referred_image"),
        }

    def __handle_chat_history(self, chat_history: List[LlmHistory]):
        chat_history_str = None
        chat_history_handler = ChatHistoryHandler()
        chat_history_str = chat_history_handler.format_chat_history(chat_history=chat_history)
        return chat_history_str
