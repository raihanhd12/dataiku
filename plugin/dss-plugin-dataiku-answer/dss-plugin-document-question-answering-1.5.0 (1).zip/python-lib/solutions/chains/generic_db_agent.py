import json
import re
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional

from backend.models.base import ConversationParams, MediaSummary
from backend.utils.context_utils import TIME_FORMAT, LLMStepMetrics, LLMStepName
from backend.utils.dataiku_api import dataiku_api
from backend.utils.llm_utils import append_summaries_to_completion_msg, prompt_date_format
from dataikuapi.dss.llm import DSSLLMCompletionQueryMultipartMessage
from langchain.prompts import ChatPromptTemplate
from llm_assist.logging import logger
from solutions.mesh.llm import AnswersDSSLLM, CompletionResponse


#TODO to refactor/inherit from GenericDecisionJSONChain
class GenericDBAgent(ABC):
    # Abstract class for Knowledge Bank Agents
    # Implement the prompt property in the child class
    @property
    def formatted_errors(self):
        if len(self.previous_sql_errors) > 0:
            errors = ""
            for idx, error_response in enumerate(self.previous_sql_errors):
                errors += f"""Attempt {idx}:
                Response:
                {error_response['response']}
                Query:
                {error_response['query']}
                Error returned
                {error_response['error']}
                ---------------------------------
                """
            return errors
        logger.debug("errors: NO ERRORS!")
        return ""

    @property
    @abstractmethod
    def graph_prompt(self):
        pass

    @abstractmethod
    def update_graph(self, selected_graph: Optional[Dict[str, Any]], justification: str):
        pass

    @property
    @abstractmethod
    def prompt(self):
        pass

    @property
    @abstractmethod
    def chosen_tables_and_columns(self):
        pass

    @property
    @abstractmethod
    def graph_justification(self):
        pass

    @property
    @abstractmethod
    def user_error_prompt(self):
        pass

    @property
    @abstractmethod
    def query_system_prompt(self):
        pass

    @property
    @abstractmethod
    def previous_sql_errors(self):
        pass

    def get_retrieval_graph(self, llm, chat_history, user_input, conversation_params: ConversationParams):
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        justification = ""
        params_dict = {"chat_history": chat_history}
        media_summaries: List[MediaSummary] = conversation_params.get("media_summaries") or []
        previous_media_summaries: List[MediaSummary] = conversation_params.get("previous_media_summaries") or []
        summaries = media_summaries or previous_media_summaries
        graph_prompt = self.graph_prompt.invoke(params_dict).to_string()
        final_graph_prompt = f"Today's date and time: {datetime.now().strftime(prompt_date_format)} \n " + graph_prompt
        text = ""
        try:
            logger.debug(f"""DB Metadata identification FINAL PROMPT {final_graph_prompt}
            Identifying necessary metadata for DB queries...""")
            llm_id = dataiku_api.webapp_config.get("json_decision_llm_id", None) or llm.llm_id
            logger.debug(f"Using LLM ID for decision chain in json format: {llm_id}")
            completion = AnswersDSSLLM(llm_id).new_completion()
            current_step = LLMStepMetrics(step_name=LLMStepName.DB_RETRIEVAL_GRAPH.value, step_start_time=start_time)
            completion.with_message(final_graph_prompt, role="system")
            if summaries:
                msg: DSSLLMCompletionQueryMultipartMessage = completion.new_multipart_message(role="user")
                append_summaries_to_completion_msg(summaries, msg)
            completion.with_message(user_input, role="user")
            resp: CompletionResponse = completion.execute(current_step)
            text = str(resp.text)
            if not resp.text and resp.errorMessage:
                raise Exception(resp.errorMessage)
            logger.debug(f"Generated response for DB queries information: {text}")
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                json_str = match.group(0)
                response_json = json.loads(json_str)
                tables_and_columns = response_json.get("tables_and_columns")
                suggested_joins = response_json.get("suggested_joins")
                justification = response_json.get("justification")
                if all(q is None for q in [tables_and_columns, suggested_joins]):
                    return self.update_graph({"tables_and_columns": None, "suggested_joins": None}, justification)
                return self.update_graph(
                    {"tables_and_columns": tables_and_columns, "suggested_joins": suggested_joins}, justification
                )
            else:
                logger.error(f"No JSON object found in the response {text}")
                raise Exception(f"No JSON object found in the response {text}")
        except json.JSONDecodeError as e:
            logger.exception(f"Error during retrieval graph processing: {e}")
            return self.update_graph(None, justification)
        except Exception as e:
            logger.exception(f"Error during retrieval graph processing: {e}")
            return self.update_graph(None, justification)

    def get_retrieval_query(self, llm, chat_history, user_input, failed_response: dict = {}):
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        justification = ""
        if self.chosen_tables_and_columns == "":
            return None, self.graph_justification
        text = ""
        try:
            query_prompt = self.prompt.invoke({"chat_history": chat_history}).to_string()
            final_query_prompt = (
                f"Today's date and time: {datetime.now().strftime(prompt_date_format)} \n " + query_prompt
            )
            completion = AnswersDSSLLM(llm.llm_id).new_completion()
            completion.with_message(final_query_prompt, role="system")
            completion.with_message(user_input, role="user")
            if not failed_response:
                logger.debug(f"DB query FINAL PROMPT {final_query_prompt}")
            resp: CompletionResponse
            if failed_response:
                logger.debug("Correcting query prompt ...")
                resp = self.fix_retrieval_query(llm, chat_history, user_input)
            else:
                logger.debug("Creating initial query prompt ...")
            current_step = LLMStepMetrics(step_name=LLMStepName.DB_RETRIEVAL_QUERY.value, step_start_time=start_time)
            resp = completion.execute(current_step)

            text = str(resp.text)
            if not text and resp.errorMessage:
                raise Exception(resp.errorMessage)
            logger.debug(f"Generated response for DB query: {text}")
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                json_str = match.group(0)
                response_json = json.loads(json_str)

                with_ = response_json.get("with")
                select_list = response_json.get("selectList")
                from_ = response_json.get("from")
                join = response_json.get("join")
                where_ = response_json.get("where")
                grp_by = response_json.get("groupBy")
                having = response_json.get("having")
                order_by = response_json.get("orderBy")
                limit = response_json.get("limit")
                justification = response_json.get("justification")

                logger.debug(
                    f"with: {with_}, select list: {select_list}, from: {from_}, join: {join}, where: {where_}, group by: {grp_by}, having: {having}, order_by: {order_by}, limit: {limit}, Justification: {justification}"
                )

                if all(q is None for q in [with_, select_list, from_, join, where_, grp_by, having, order_by, limit]):
                    return None, justification

                query_dict = {
                    "with": with_,
                    "selectList": select_list,
                    "from": from_,
                    "join": join,
                    "where": where_,
                    "groupBy": grp_by,
                    "having": having,
                    "orderBy": order_by,
                    "limit": limit,
                }
                return query_dict, justification
            else:
                logger.error(f"No JSON object found in the response {text}")
                raise Exception(f"No JSON object found in the response {text}")
        except json.JSONDecodeError as e:
            logger.exception(f"Error decoding JSON during retrieval query processing: {e}. Response received: {text}")
            return None, justification
        except Exception as e:
            logger.exception(f"Error during retrieval query processing: {e}. Response received: {text}")
        return None, justification

    def fix_retrieval_query(self, llm, chat_history, user_input) -> CompletionResponse:
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        assert self.user_error_prompt, "An error prompt must be assigned in order to correct query errors"
        logger.debug(f"DB query: attempting to fix previous errors  {self.previous_sql_errors}")

        error_system_prompt = f"""
        Today's date and time: {datetime.now().strftime(prompt_date_format)} \n ",
        You are an expert in fixing SQL query errors. You help the query build to fix its errors.
        Look at  chat history, task and response and fix it. It is essential that your response in the same JSON format as the task.
        Provide the JSON object only. Do not add any other explanations, decorations, or additional information beyond the JSON object.
        Here the instructions that the query builder received 
        # Previous instructions:
        {self.query_system_prompt}
        """

        formatted_errors = ""
        for idx, error_response in enumerate(self.previous_sql_errors):
            formatted_errors += f"""Attempt {idx}:
            Response:
            {error_response['response']}
            Query:
            {error_response['query']}
            Error returned
            {error_response['error']}
            ---------------------------------
            """

        attempts_history_prompt = f"""
        This is the attempt history:
        {formatted_errors}
        Corrected response:
        """
        logger.debug(f"""Error correction prompt: {self.user_error_prompt}
        Error correct user input: {user_input}""")
        error_prompt = (
            ChatPromptTemplate.from_messages([("system", error_system_prompt), ("user", self.user_error_prompt)])
            .invoke({"chat_history": chat_history})
            .to_string()
        )
        logger.debug(f"Error correction prompt: {error_prompt}")
        completion = AnswersDSSLLM(llm.llm_id).new_completion()
        completion.with_message(error_prompt, role="system")
        completion.with_message(attempts_history_prompt, role="system")
        completion.with_message(user_input, role="user")
        current_step = LLMStepMetrics(step_name=LLMStepName.DB_FIX_RETRIEVAL_QUERY.value, step_start_time=start_time)
        resp: CompletionResponse = completion.execute(current_step)
        return resp
