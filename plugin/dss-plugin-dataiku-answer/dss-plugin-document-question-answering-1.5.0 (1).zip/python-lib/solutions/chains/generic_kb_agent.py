import json
import re
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List

from backend.models.base import ConversationParams, MediaSummary
from backend.utils.context_utils import TIME_FORMAT, LLMStepMetrics, LLMStepName
from backend.utils.dataiku_api import dataiku_api
from backend.utils.llm_utils import append_summaries_to_completion_msg, prompt_date_format
from dataikuapi.dss.llm import DSSLLMCompletionQueryMultipartMessage
from llm_assist.logging import logger
from solutions.mesh.llm import AnswersDSSLLM, CompletionResponse


#TODO to refactor/inherit from GenericDecisionJSONChain
class GenericKBAgent(ABC):
    # Abstract class for Knowledge Bank Agents
    # Implement the prompt property in the child class
    @property
    @abstractmethod
    def prompt(self):
        pass

    def get_retrieval_query(self, llm, chat_history, user_input, conversation_params: ConversationParams):
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        justification = ""
        user_profile = conversation_params.get("user_profile", {})
        media_summaries: List[MediaSummary] = conversation_params.get("media_summaries") or []
        previous_media_summaries: List[MediaSummary] = conversation_params.get("previous_media_summaries") or []
        summaries = media_summaries or previous_media_summaries
        include_user_profile = dataiku_api.webapp_config.get("include_user_profile_in_KB_prompt", False)
        logger.debug(f" include_user_profile: {include_user_profile}")
        params_dict = {"chat_history": chat_history}
        if include_user_profile:
            params_dict.update({"user_profile": user_profile})
        try:
            logger.debug("Generating prompt for LLM...")
            prompt = self.prompt.invoke(params_dict).to_string()
            final_prompt = f"Today's date and time: {datetime.now().strftime(prompt_date_format)} \n " + prompt
            logger.debug(f"Knowledge Bank retrieval query FINAL PROMPT {final_prompt}")
            llm_id = dataiku_api.webapp_config.get("json_decision_llm_id", None) or llm.llm_id
            logger.debug(f"Using LLM ID for decision chain in json format: {llm_id}")
            completion = AnswersDSSLLM(llm_id).new_completion()
            completion.with_message(final_prompt, role="system")
            if summaries:
                msg: DSSLLMCompletionQueryMultipartMessage = completion.new_multipart_message(role="user")
                msg.with_text(final_prompt)
                append_summaries_to_completion_msg(summaries, msg)
            completion.with_message(user_input, role="user")
            current_step = LLMStepMetrics(step_name=LLMStepName.KB_RETRIEVAL_QUERY.value, step_start_time=start_time)
            resp: CompletionResponse = completion.execute(current_step)
            text = str(resp.text)
            logger.debug(f"Generated response for knowledge bank: {text}")
            if not text and resp.errorMessage:
                raise Exception(resp.errorMessage)
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                json_str = match.group(0)
                response_json = json.loads(json_str)
                query = response_json.get("query")
                justification = response_json.get("justification")
                logger.debug(f"Query: {query}, Justification: {justification}")
                return query, justification
            else:
                logger.error(f"No JSON object found in the response {text}")
                raise Exception(f"No JSON object found in the response {text}")
        except json.JSONDecodeError as e:
            logger.exception("Failed to decode JSON response")
        except Exception as e:
            logger.exception("Failed to build query for knowledge bank: {e}")
        return user_input, justification
