import json
import re
from typing import Optional, Tuple

from backend.db.sql.sql_timing import log_query_time
from backend.models.base import MediaSummary
from backend.utils.context_utils import LLMStepMetrics, LLMStepName
from dataikuapi.utils import DataikuException
from langchain.prompts import ChatPromptTemplate
from llm_assist.llm_api_handler import llm_setup
from llm_assist.logging import logger
from solutions.mesh.llm import AnswersDSSLLM, CompletionResponse

LLM = llm_setup.get_llm()
#TODO this should be refactored as it seems very similar to the one in doc_as_image_summary_chain.py and image_summary_chain.py
@log_query_time
def get_text_extraction_summary(extracted_text: str, original_file_name: str, language: Optional[str], start_time: str) -> Tuple[Optional[MediaSummary], Optional[str]]:
    summary = MediaSummary(summary=None, topics=None, questions=None, full_extracted_text=extracted_text)

    text_extraction_system_prompt = """
    # Role and Guidelines
    Your role is to read and summarise the text provided to you. This text is extracted from a document uploaded to a webapp.
    You must mention the contents of each section or chapter of the document if they exist.
    You should provide your answer in JSON format with the following keys
    - "summary": str: summary of the whole document provided to you
    - "topics": Array[str]: array of all the main topics discussed in the text provided.
    - "questions": Array[str]: array of 3 questions which can be asked based on the text provided to you. They should be fact based questions, not opinion based.
    The JSON object should have double quotes for keys and values. It is important to follow the JSON format strictly.
    Provide a JSON object only. Do not add any other explanations, decorations, or additional information beyond the JSON object.
    """
    text_extraction_user_prompt = """
    Summarise the following extracted document text
    # Extracted Text
    {extracted_text}
    # --- END OF EXTRACTED TEXT ---
    Your JSON object:
    """
    if language:
        text_extraction_system_prompt += f"""
    Your response should be in {language}
    """
    summary_prompt = ChatPromptTemplate.from_messages(
        [("system", text_extraction_system_prompt), ("user", text_extraction_user_prompt)]
    )

    message = summary_prompt.invoke({"extracted_text": extracted_text}).to_string()
    completion = AnswersDSSLLM(LLM.llm_id).new_completion()
    completion.with_message(message)
    text = ""
    try:
        current_step = LLMStepMetrics(step_name=LLMStepName.TEXT_EXTRACTION_SUMMARY.value, step_start_time=start_time, document_name=original_file_name)
        resp: CompletionResponse = completion.execute(current_step)
        text = str(resp.text)
        if not text and resp.errorMessage:
            return None, resp.errorMessage
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            json_str = match.group(0)
            summary = json.loads(json_str)
            return summary, None
        else:
            msg = f"No JSON object found in the response {text}"
            logger.error(msg)
            raise Exception(text)
    except json.JSONDecodeError as e:
        msg = f"Error decoding JSON during text summarization: {e}. Response received: {text}"
        logger.exception(msg)
        raise Exception(text)
    except DataikuException as e:
        msg = f"Dataiku API Error: {e}."
        logger.exception(msg)
        raise e
    except Exception as e:
        msg = f"An error occurred during text summarization: {e}. Response received: {text}"
        logger.exception(msg)
        raise e
