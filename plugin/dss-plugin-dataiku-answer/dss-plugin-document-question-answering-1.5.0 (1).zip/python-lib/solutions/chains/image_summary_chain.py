import json
import re
from typing import Optional, Tuple

from backend.db.sql.sql_timing import log_query_time
from backend.models.base import MediaSummary
from backend.utils.context_utils import LLMStepMetrics, LLMStepName
from dataikuapi.utils import DataikuException
from langchain.chains import ConversationChain
from langchain.prompts import PromptTemplate
from llm_assist.llm_api_handler import llm_setup
from llm_assist.logging import logger
from solutions.mesh.llm import AnswersDSSLLM, CompletionResponse

LLM = llm_setup.get_llm()


@log_query_time
def get_image_summary(
    img_b64: str, original_file_name: str, language: Optional[str], start_time: str
) -> Tuple[Optional[MediaSummary], Optional[str]]:
    image_summary_system_prompt = """# Role and Guidelines
    Your role is to look at and summarise the image provided to you. This image has been uploaded to a webapp.
    Your summary should mention the contents of each section of the document if possible.
    You should provide your answer in JSON format with the following keys
    - "summary": str: summary of the whole image provided to you
    - "topics": Array[str]: array of all the main topics that appear in the image provided.
    - "questions": Array[str]: array of 3 questions which can be asked based on the image provided to you.
    The JSON object should have double quotes for keys and values. It is important to follow the JSON format strictly.
    Provide a JSON object only. Do not add any other explanations, decorations, or additional information beyond the JSON object.
    """
    image_summary_user_prompt = """Summarise the following extracted image
    Your JSON object:
    """
    if language:
        image_summary_system_prompt += f"""
    Your response should be in {language}
    """
    summary = MediaSummary(summary=None, topics=None, questions=None)
    template = r"""
        {system_prompt}
        {{history}}
        Human: {{input}}
        Assistant:""".format(system_prompt=image_summary_system_prompt)
    qa_prompt = PromptTemplate(input_variables=["input", "history"], template=template)

    qa_chain = ConversationChain(llm=LLM, verbose=True, prompt=qa_prompt)
    computed_prompt = qa_chain.prep_prompts(input_list=[{"input": image_summary_user_prompt, "history": ""}])
    prompt = computed_prompt[0][0]
    completion = AnswersDSSLLM(LLM.llm_id).new_completion()
    msg = completion.new_multipart_message()

    msg.with_text(prompt.to_string()).with_text(f"Image file name: {original_file_name}").with_inline_image(
        img_b64
    ).add()
    text = ""
    try:
        current_step = LLMStepMetrics(
            step_name=LLMStepName.IMAGE_SUMMARY.value, document_name=original_file_name, step_start_time=start_time
        )
        resp: CompletionResponse = completion.execute(current_step)
        text = str(resp.text)
        if not text and resp.errorMessage:
            return None, resp.errorMessage
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            json_str = match.group(0)
            summary = json.loads(json_str)
            return summary, None
        else:
            msg = f"No JSON object found in the response {text}"
            logger.error(msg)
            raise Exception(text)
    except json.JSONDecodeError as e:
        msg = f"Error decoding JSON during image summarization: {e}. Response received: {text}"
        logger.exception(msg)
        raise Exception(text)
    except DataikuException as e:
        msg = f"Dataiku API Error: {e}. "
        logger.exception(msg)
        raise e
    except Exception as e:
        msg = f"Error during image summarization: {e}. Response received: {text}"
        logger.exception(msg)
        raise e
