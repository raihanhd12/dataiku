import json
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union, cast

from backend.models.base import (
    ConversationParams,
    LlmHistory,
    LLMStep,
    MediaSummary,
    Source,
)
from backend.utils.context_utils import TIME_FORMAT, LLMStepMetrics, LLMStepName
from backend.utils.dataiku_api import dataiku_api
from backend.utils.knowledge_banks_params import KnowledgeBanksParams
from backend.utils.knowledge_filters import process_filters_for_db
from backend.utils.llm_utils import handle_prompt_media_explanation, prompt_date_format
from backend.utils.rag_sources import map_rag_sources
from dataiku.langchain.dku_llm import DKULLM
from langchain.prompts import PromptTemplate
from langchain.retrievers import EnsembleRetriever
from langchain.schema.document import Document
from langchain_core.prompt_values import PromptValue
from llm_assist.logging import logger
from solutions.chains.conversation_retrieval import DKUConversationRetrievalChain
from solutions.chains.description_based_kb_agent import DescriptionBasedKBAgent
from solutions.chains.generic_answers_chain import GenericAnswersChain
from solutions.chains.generic_kb_agent import GenericKBAgent
from solutions.chains.simple_kb_agent import SimpleKBAgent
from solutions.knowledge_bank import get_knowledge_bank_retriever
from solutions.mesh.llm import AnswersDSSLLM, CompletionResponse
from solutions.prompts.citations import CITATIONS_PROMPT
from solutions.prompts.conversations import ChatHistoryHandler


class KBRetrievalChain(GenericAnswersChain):
    def __init__(self, llm: DKULLM, query: str, filters: Optional[Dict[str, List[Any]]], chat_has_media: bool = False):
        self.__llm = llm
        self.__kbs_params = KnowledgeBanksParams()
        self.__act_like_prompt = ""
        self.__system_prompt = ""
        self.__prompt_with_media_explanation = chat_has_media
        self.__qa_chain: Optional[DKUConversationRetrievalChain] = None
        self.__knowledge_banks_to_use: List[str] = []
        self.__computed_prompt: Optional[PromptValue] = None
        self.__filters = self.__create_kb_filters(filters, query)
        self.__retrieval_query_agent: GenericKBAgent
        if self.webapp_config.get("enable_smart_usage_of_kb", True):
            self.__retrieval_query_agent = DescriptionBasedKBAgent(chat_has_media=chat_has_media)
        else:
            self.__retrieval_query_agent = SimpleKBAgent(chat_has_media=chat_has_media)

    @property
    def qa_chain(self) -> DKUConversationRetrievalChain:
        if self.__qa_chain is None:
            raise ValueError("QA chain is not initialized.")
        return self.__qa_chain

    @property
    def act_like_prompt(self) -> str:
        return self.__act_like_prompt

    @property
    def system_prompt(self) -> str:
        return self.__system_prompt

    @property
    def computed_prompt(self) -> PromptValue:
        if self.__computed_prompt is None:
            raise ValueError("Computed prompt is not initialized.")
        return self.__computed_prompt

    @property
    def filters(self) -> Any:
        return self.__filters

    @property
    def knowledge_banks_to_use(self) -> List[str]:
        return self.__knowledge_banks_to_use

    @property
    def retrieval_query_agent(self) -> GenericKBAgent:
        return self.__retrieval_query_agent

    @property
    def llm(self) -> DKULLM:
        return self.__llm

    @property
    def chain_purpose(self) -> str:
        return LLMStepName.KB_ANSWER.value

    def __verify_filters(self, filters: Dict[str, List[Any]]) -> Optional[Dict[str, List[Any]]]:
        if not filters or not self.__kbs_params.filters_config:
            return None
        verified_columns = [col for col in filters.keys() if col in self.__kbs_params.filters_config["filter_columns"]]
        verified_filters = {}
        for col in verified_columns:
            verified_values = [
                value for value in filters[col] if value in self.__kbs_params.filters_config["filter_options"][col]
            ]

            verified_filters[col] = verified_values

        return verified_filters

    def __create_kb_filters(self, filters: Optional[Dict[str, List[Any]]], query: str) -> Dict[str, Any]:
        # TODO: Adapt when several knowledge banks will be connected
        vector_db_type = self.__kbs_params.knowledge_bank_vector_db_types[0]
        if vector_db_type and filters and len(filters) > 0:
            verified_filters = process_filters_for_db(  # TODO: Adapt when several knowledge banks will be connected
                self.__verify_filters(filters=filters), vector_db_type
            )
            logger.debug(f"vector_db_type:{vector_db_type}   / filters: {filters}")
            # TODO: Adapt when several knowledge banks will be connected
            return {self.__kbs_params.knowledge_bank_ids[0]: verified_filters}
        else:
            if (
                (filters is None or len(filters) == 0)
                and self.__kbs_params.filters_config
                and self.webapp_config.get("knowledge_enable_auto_filtering", False)
            ):
                computed_filters = self.__auto_filters(query, self.__kbs_params.filters_config["filter_options"])
                return {
                    self.__kbs_params.knowledge_bank_ids[0]: process_filters_for_db(
                        filters=computed_filters, vector_db_type=vector_db_type
                    )
                }
            else:
                # TODO: Adapt when several knowledge banks will be connected
                return {self.__kbs_params.knowledge_bank_ids[0]: {}}

    def __extract_json(self, response_text: str) -> Dict[str, Any]:
        # Find all characters that could be the start or end of a JSON object
        json_objects = re.findall(r"{.*?}", response_text)
        # Find the longest string that could be a JSON object,
        # since it's most likely to be the correct one
        longest_json = max(json_objects, key=len, default="{}")
        # Convert the string back to a dictionary (JSON object)
        try:
            json_data: Dict[str, Any] = json.loads(longest_json)
        except json.JSONDecodeError as e:
            logger.exception(f"Error parsing filters json: {e}")
            # In case JSON decoding fails, just return an empty dictionary
            json_data = {}

        return json_data

    def __auto_filters(
        self, user_query: str, possible_filters: Dict[str, List[str]]
    ) -> Union[Dict[str, List[str]], None]:
        """Analyzes the user query and identifies the relevant filters and their values.
        Args:
            user_query (str): The user query.
            possible_filters (List[str]): A dictionary containing the possible filters and their values.

        Returns:
            Dict[str, List[str]]: A dictionary containing the relevant filters and their values.
        """
        logger.debug("Auto Filtering On")
        datetime_now = datetime.now().strftime(prompt_date_format)
        prompt = (
            f"Today's date and time: {datetime_now} "
            f"Examine the user query and Identify which of the following possible filter values are relevant: "
            "# POSSIBLE FILTERS: "
            f"{possible_filters}. "
            "# INSTRUCTIONS "
            "1 - Return only a JSON object of the relevant filters directly, with no additional explanations, text decorations, "
            "or markdown. Ensure the JSON object is in a format that can be parsed directly by a JSON parser without needing "
            "any preprocessing. "
            "2- If no filters apply or if you are not sure about the relevant filters, return an empty JSON object: {}. "
            "3- Remember to strictly return the relevant filters JSON object with no additional text or markdown. "
            "### EXAMPLES: "
            "- Example 1: "
            "user query: What are the revenues for Q1 2023 and Q2 in 2023? "
            'possible filters: {"file":["2023 Q2.pdf", "2023 Q1.pdf","2024 Q2.pdf"]} '
            'Expected Answer is: {"file":["2023 Q2.pdf", "2023 Q1.pdf"]}. '
            "- Example 2: "
            "user query: How many vacation days do we have in California. "
            'possible filters: {"location":["California", "New York", "Texas", "Paris"], "tags": ["source","name","url"], "date": ["2022","2023","2024"]} '
            'Expected Answer is: {"location":["California"]}. '
            "- Example 3: "
            "user query: What are the sales for the 2023 last quarter for Microsoft and Samsung? "
            'possible filters: {"company":["Apple", "Microsoft", "Samsung"], "quarter": ["Q1","Q2","Q3","Q4"], "year": ["2022","2023","2024"]} '
            'Expected Answer is: {"company":["Microsoft", "Samsung"], "quarter": ["Q4"], "year": ["2023"]}. '
            "- Example 4: "
            "user query: How many employees are in the marketing department? "
            'possible filters: {"location": ["Paris", "New York", "London"]} '
            "Expected Answer is: {}. "
        )

        logger.debug(f"Auto filters prompt: {prompt}")
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        response = None
        try:
            completion = AnswersDSSLLM(self.llm.llm_id).new_completion()
            completion.with_message(prompt, role="system")
            completion.with_message(user_query, role="user")
            current_step = LLMStepMetrics(step_name=LLMStepName.KB_AUTO_FILTERING.value, step_start_time=start_time)
            llm_response: CompletionResponse = completion.execute(current_step)
            response = str(llm_response.text)
            if not response and llm_response.errorMessage:
                raise Exception(llm_response.errorMessage)
            logger.debug(f"Auto filters llm response: '{response}'")

            if isinstance(response, dict):
                relevant_filters = response
            else:
                relevant_filters = self.__extract_json(response)
            logger.debug(f"Extracted filters  {relevant_filters}")
            validated_filters = self.__verify_filters(relevant_filters)

            return validated_filters
        except Exception as e:
            logger.exception(f"Failed to parse LLM response for query '{user_query}'. Exception: {e}")
            return {}

    def __get_ensemble_retriever(self, filters={}) -> EnsembleRetriever:
        knowledge_bank_retrievers = []
        logger.debug(f"weights: {self.__kbs_params.knowledge_bank_weighs}")
        logger.debug(f"knowledge_banks_to_use: {self.knowledge_banks_to_use}")
        for knowledge_bank_id in self.knowledge_banks_to_use:
            knowledge_bank_filter = filters[knowledge_bank_id]
            knowledge_bank_retriever = get_knowledge_bank_retriever(
                knowledge_bank_id,
                knowledge_bank_filter,
                self.__kbs_params.all_knowledge_bank_parameters["retrieval_parameters"]["search_type"],
            )
            knowledge_bank_retrievers.append(knowledge_bank_retriever)
        if self.__kbs_params.knowledge_bank_weighs:
            ensemble_retriever = EnsembleRetriever(
                retrievers=knowledge_bank_retrievers, weights=self.__kbs_params.knowledge_bank_weighs
            )
        else:
            ensemble_retriever = EnsembleRetriever(retrievers=knowledge_bank_retrievers)  # type: ignore
        return ensemble_retriever

    def load_role_and_guidelines_prompts(self, params: ConversationParams):
        if self.knowledge_banks_to_use:
            act_like_prompt = self.webapp_config.get("knowledge_bank_prompt", "")
            system_prompt = dataiku_api.webapp_config.get(
                "knowledge_bank_system_prompt",
                "Given the following specific context and the conversation between a human and an AI, please give a short answer to the question at the end, If you don't know the answer, just say that you don't know, don't try to make up an answer.",
            )
        else:
            act_like_prompt, system_prompt = self.load_default_role_and_guidelines_prompts()
        user_profile = params.get("user_profile", None)
        include_full_user_profile = bool(self.webapp_config.get("include_user_profile_in_KB_prompt", False))
        system_prompt = self.append_user_profile_to_prompt(
            system_prompt=system_prompt, user_profile=user_profile, include_full_user_profile=include_full_user_profile
        )
        system_prompt = handle_prompt_media_explanation(
            system_prompt=system_prompt, has_media=self.__prompt_with_media_explanation
        )
        self.__act_like_prompt = act_like_prompt
        self.__system_prompt = system_prompt

    def create_chain(self, params: ConversationParams) -> DKUConversationRetrievalChain:
        # TODO check how to handle if self.knowledge_banks_to_use:
        datetime_now = datetime.now().strftime(prompt_date_format)
        enable_llm_citations = self.webapp_config.get("enable_llm_citations", False)
        context_prompt = CITATIONS_PROMPT if enable_llm_citations else "### CONTEXT"
        general_retrieval_template = r""" 
        Today's date and time: {datetime_now}
        {act_like_prompt}
        
        {system_prompt}

        {context_prompt}

        ----
        {{context}}
        ----
        
        Chat history:
        {{chat_history}}
        --- End of Chat history ---
        Assistant:""".format(
            datetime_now=datetime_now,
            act_like_prompt=self.act_like_prompt,
            system_prompt=self.system_prompt,
            context_prompt=context_prompt,
        )
        logger.debug("Building general_user_template")
        qa_prompt = PromptTemplate(input_variables=["history", "input"], template=general_retrieval_template)
        retriever_chain = self.__get_ensemble_retriever(filters=self.filters)
        dku_chain = DKUConversationRetrievalChain.from_llm(
            llm=self.llm,
            retriever=retriever_chain,
            return_source_documents=True,
            verbose=True,
            condense_question_llm=self.llm,
            chain_type="stuff",
            combine_docs_chain_kwargs={"prompt": qa_prompt},
        )
        self.__qa_chain = cast(DKUConversationRetrievalChain, dku_chain)
        return self.qa_chain

    def get_computing_prompt_step(self, params: ConversationParams) -> LLMStep:
        if self.knowledge_banks_to_use:
            return LLMStep.COMPUTING_PROMPT_WITH_KB
        else:
            return LLMStep.COMPUTING_PROMPT_WITHOUT_RETRIEVAL

    def get_querying_step(self, params: ConversationParams) -> LLMStep:
        if self.knowledge_banks_to_use:
            step = LLMStep.QUERYING_LLM_WITH_KB
        else:
            step = LLMStep.QUERYING_LLM_WITHOUT_RETRIEVAL
        return step

    def finalize_streaming(
        self,
        params: ConversationParams,
        question_context: Union[str, Dict[str, Any], List[str]],
    ) -> Dict[str, Any]:
        user_profile = params.get("user_profile", None)

        # Send sources and filters at the end of the streaming
        return self.get_as_json(
            question_context, user_profile=user_profile, uploaded_docs=params.get("media_summaries", [])
        )

    def finalize_non_streaming(
        self,
        params: ConversationParams,
        question_context: Union[str, Dict[str, Any], List[str]],
    ) -> Dict[str, Any]:
        return self.finalize_streaming(params=params, question_context=question_context)

    def create_computed_prompt(self, params: ConversationParams) -> Tuple[PromptValue, Dict[str, Any]]:
        user_query = params.get("user_query", "")
        kb_query = params.get("kb_query", "")
        kb_query = kb_query if kb_query is not None else ""
        chat_history = params.get("chat_history", [])
        question_context: Dict[str, Any] = {}
        if self.knowledge_banks_to_use:
            enable_llm_citations = self.webapp_config.get("enable_llm_citations", False)
            self.__computed_prompt, question_context = self.qa_chain.prepare_final_answer_prompt(
                condensed_query=user_query,
                kb_query=kb_query,
                inputs={"chat_history": self.format_history(chat_history)},
                enable_llm_citations=enable_llm_citations,
            )
        else:
            # TODO test this case
            raise ValueError(
                "No knowledge bank selected. This chain should not be used. Use No Retrieval Chain instead."
            )
        logger.debug(f"Final prompt:  {self.__computed_prompt.to_string() if self.__computed_prompt else 'No prompt'}")
        return self.computed_prompt, question_context

    def get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any], List[str]],
        user_profile: Optional[Dict[str, Any]] = None,
        uploaded_docs: Optional[List[MediaSummary]] = None,
    ) -> Dict[str, Any]:
        llm_context: Dict[str, Any] = {}

        def handle_filters(filters):
            if filters is not None and isinstance(filters, dict):
                result = (
                    filters.get(self.knowledge_banks_to_use[0], None)
                    if filters and self.knowledge_banks_to_use
                    else None
                )
                return None if result == {} else result
            return filters

        self.__filters = handle_filters(self.__filters)
        if self.knowledge_banks_to_use:
            llm_context["llm_kb_selection"] = self.knowledge_banks_to_use
        if user_profile:
            llm_context["user_profile"] = user_profile
        if isinstance(generated_answer, str):
            return {
                "answer": generated_answer,
                "sources": [],
                "filters": self.filters,
                "knowledge_bank_selection": self.knowledge_banks_to_use,
            }
        llm_context["uploaded_docs"] = (
            [
                {
                    "original_file_name": str(uploaded_docs.get("original_file_name")),
                    "metadata_path": str(uploaded_docs.get("metadata_path")),
                }
                for uploaded_docs in uploaded_docs
            ]
            if uploaded_docs
            else []
        )
        if isinstance(generated_answer, dict):
            answer = generated_answer.get("answer", "")
            source_documents: List[Document] = generated_answer.get("source_documents", [])
            sources = []
            for document in source_documents:
                source_content = document.page_content
                source_metadata = document.metadata

                sources.append(dict(Source(excerpt=source_content, metadata=source_metadata)))

            sources = map_rag_sources(sources)
            return {"answer": answer, "sources": sources, "filters": self.filters, "llm_context": llm_context}
        logger.error(f"Generated answer type not supported. This should not happen. {generated_answer}")
        return {}

    def create_query_from_history_and_update_params(
        self, chat_history: List[LlmHistory], user_query: str, params: ConversationParams
    ):
        chat_history_str = None
        chat_history_handler = ChatHistoryHandler()
        chat_history_str = chat_history_handler.format_chat_history(chat_history=chat_history)

        retrieval_query, justification = self.retrieval_query_agent.get_retrieval_query(
            llm=self.llm, chat_history=chat_history_str, user_input=user_query, conversation_params=params
        )
        params["justification"] = justification

        params["kb_query"] = retrieval_query
        logger.debug(f"Computed Retrieval query from the user query: [{user_query}], is [{retrieval_query}]")

        self.__knowledge_banks_to_use = [] if params["kb_query"] is None else self.__kbs_params.knowledge_bank_ids
        params["knowledge_bank_selection"] = self.knowledge_banks_to_use
        if self.__knowledge_banks_to_use == []:
            logger.warn("No knowledge bank has been selected but knowledge bank is enabled.")
        logger.debug(f"""Selected knowledge bank: {self.knowledge_banks_to_use}
        retrieval_enabled: {params['retrieval_enabled']}""")
        return params
