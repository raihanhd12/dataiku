from backend.utils.dataiku_api import dataiku_api
from backend.utils.llm_utils import handle_prompt_media_explanation
from langchain.prompts import ChatPromptTemplate
from llm_assist.logging import logger
from solutions.chains.generic_kb_agent import GenericKBAgent


class SimpleKBAgent(GenericKBAgent):
    # Simple Agent that build a search query for kb based on the last user input
    # in the chat history unless it is a terminal statement.
    def __init__(self, chat_has_media: bool = False):
        # Define the prompt for the agent
        include_user_profile = dataiku_api.webapp_config.get("include_user_profile_in_KB_prompt", False)

        profile_examples = (
            [
                """
            # USER PROFILE:
            {{
                "country": {{
                    "value": "USA",
                    "description": "country"
                }}
            }}
            # --- END OF USER PROFILE ---
        """,
                """
            # USER PROFILE:
            {{
                "department": {{
                    "value": "IT",
                    "description": "the department of the user"
                }}
            }}
        # --- END OF USER PROFILE ---
        """,
                """
            # USER PROFILE:
            {{
                "group": {{
                    "value": "Data Scientists",
                    "description": "the LDAP group of the user"
                }}
            }}
            # --- END OF USER PROFILE ---
        """,
            ]
            if include_user_profile
            else ["", "", ""]
        )
        profile_example1_mention1 = "in the USA" if include_user_profile else ""
        profile_example1_mention2 = (
            " In addition the user profile indicates that the user is in the USA" if include_user_profile else ""
        )

        examples_template = """
            ### Example Scenarios:
            
            #### Example 1:
                {profile_example_1}
                CHAT HISTORY:
                [HumanMessage(content="Hello"),
                AIMessage(content="Hi there! How may I assist you today?")]
                Human: "What is our policy on remote work?"
                EXPECTED OUTPUT: {{{{
                    "query": "Remote work policy at my company {profile_example1_mention1}.",
                    "justification": "The user is asking a question related to internal policies, so it requires further information from knowledge bank. {profile_example1_mention2}"
                }}}}

            #### Example 2:
                {profile_example_2}
                CHAT HISTORY:
                [HumanMessage(content="Good morning"),
                AIMessage(content="Good morning! How may I assist you today?")]
                Human: "Just checking in, thanks!"
                EXPECTED OUTPUT: {{{{
                    "query": null,
                    "justification": "The user's input is a terminal statement and does not require further information."
                }}}}

            #### Example 3:
                {profile_example_3}
                CHAT HISTORY:
                [HumanMessage(content="Hello"),
                AIMessage(content="Hello! How may I assist you today?")]
                [HumanMessage(content="count to 20"),
                AIMessage(content="1, 2, 3, ..., 20"),
                Human:"Thanks!"
                EXPECTED OUTPUT: {{{{
                    "query": null,
                    "justification": "The user's input is a terminal statement and does not require further information."
                }}}}
        """
        examples = examples_template.format(
            profile_example_1=profile_examples[0],
            profile_example_2=profile_examples[1],
            profile_example_3=profile_examples[2],
            profile_example1_mention1=profile_example1_mention1,
            profile_example1_mention2=profile_example1_mention2,
        )
        user_profile_mention = ", user profile" if include_user_profile else ""
        system_prompt = f"""
            You are a search query builder for a knowledge bank. Your role is to analyze the chat history{user_profile_mention} and last user input 
            and decide whether additional information retrieval is necessary from knowledge bank.
            If user provided documents or images, consider them as well. In that case, the documents/images would have been uploaded to a webapp and you would have the extracted texts and or images. 
            If for any reason, you don't have any information about the provided documents/images, ignore them and don't mention it to user.
            If there is any doubt, prioritize crafting a search query rather than skipping it.

            # Knowledge Bank Overview
            The knowledge bank is a vector database designed to help in answering questions by providing relevant information.

            # Your Task
            Analyze the chat history and last user input. If the chat suggests the need for more information, 
            produce a search query based on the decision criteria outlined below. 
            Produce the response as a JSON object with two fields: 'query' and 'justification'.
            If no query is needed, 'query' should be null and 'justification' should explain why no query is necessary.
            Provide the JSON object only. Do not add any other explanations, decorations, or additional information.

            # Decision Criteria:
            - Inquiry: Generate a search query if the latest input from the user in the chat history implies a need for more information.
                
            - Response Protocol: If a last user input does not directly require information from the Knowledge Bank, the 'query' should be null.
            This is critical to ensure that the system remains focused and only retrieves or provides information when it is relevant to do so.

            - Terminal Input: If the last input from the user in the chat history is a brief greeting or a closure statement.
            - Ensure that in ambiguous situations, you lean toward generating a query to maintain proactive information retrieval.
            {examples}
        """
        user_profile_section = (
            """
            # USER PROFILE:
            The following is the user’s profile, which provides context about the Human:
            {user_profile}
            # --- END OF USER PROFILE ---        
            """
            if include_user_profile
            else ""
        )

        system_prompt = handle_prompt_media_explanation(system_prompt=system_prompt, has_media=chat_has_media)
        user_profile_mention2 = (
            "Consider information provided by the user profile and, if meaningful, take it into account while crafting the search query"
            if include_user_profile
            else ""
        )
        user_prompt = """
            Evaluate the following chat history to determine if a semantic search query should be generated.
            Generate the response as a JSON object with two fields: 'query' and 'justification'.
            {user_profile_mention2}
            Generate a search query only if there is a need for more information.
            If no query is needed, 'query' should be null and 'justification' should explain why no query is necessary.
            Provide the JSON object only. Do not add any other explanations, decorations, or additional information beyond the JSON object.

            {user_profile_section}
            
            # CHAT HISTORY:
            {{chat_history}}
            # --- END OF CHAT HISTORY ---
            Your JSON object with double quotes for keys and values:
        """.format(user_profile_section=user_profile_section, user_profile_mention2=user_profile_mention2)

        self._prompt = ChatPromptTemplate.from_messages([("system", system_prompt), ("user", user_prompt)])

        logger.debug(f"SimpleKBAgent prompt is : {self.prompt }")

    @property
    def prompt(self):
        return self._prompt
