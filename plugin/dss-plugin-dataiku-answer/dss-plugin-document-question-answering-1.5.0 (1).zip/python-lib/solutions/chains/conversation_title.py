from langchain.prompts import PromptTemplate


class ConversationTitleChainHandler:
    def __init__(self, prompt_template: str):
        self._prompt = PromptTemplate.from_template(prompt_template)
        self.chain = None

    def get_prompt(self, llm) -> PromptTemplate:
        return self._prompt