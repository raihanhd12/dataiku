# import json
# from typing import Any, Dict, List, Optional, Tuple

# from langchain.callbacks.manager import CallbackManagerForChainRun
# from langchain.schema.document import Document
# from langchain_core.prompt_values import PromptValue
# from solutions.chains.conversation_retrieval import DKUConversationRetrievalChain
# from solutions.prompts.conversations import ChatHistoryHandler


################
# Make Retrieval Chain
###############

# class DKUSelfServiceConversationRetrievalChain(DKUConversationRetrievalChain):
#     def from_retriever_documents_to_structured_context(self, list_of_documents: List[Document]) -> str:
#         structured_documents = []
#         for document_index, document in enumerate(list_of_documents):
#             structured_document = {
#                     "Source number": document_index + 1,
#                     "Content": document.page_content,
#                 }
#             structured_documents.append(structured_document)
#         documents_context = json.dumps(structured_documents, ensure_ascii=False, indent=4)
#         return documents_context

#     def prepare_final_answer_prompt(
#         self,
#         condensed_query: str,
#         kb_query: str,
#         inputs: Dict[str, Any],
#         run_manager: Optional[CallbackManagerForChainRun] = None,
#     ) -> Tuple[List[PromptValue], Dict[str, Any]]:
        
#         _run_manager = run_manager or CallbackManagerForChainRun.get_noop_manager()
#         chat_history_handler = ChatHistoryHandler()
#         chat_history_str = chat_history_handler.format_chat_history(
#         chat_history=inputs["chat_history"], dialogs_format="tuples")
#         # Extract docs
#         docs = self._extract_docs(inputs, question=kb_query, run_manager=_run_manager)
#         final_inputs = self._prepare_llm_inputs(
#             inputs, question=condensed_query,
#             docs=docs, run_manager=_run_manager,
#             chat_history_str=chat_history_str,
#         )
#         computed_prompt = self.combine_docs_chain.llm_chain.prep_prompts(
#             input_list=[final_inputs], run_manager=_run_manager
#         )

#         question_info: Dict[str, Any] = {}
#         return computed_prompt[0][0], question_info
