import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union

from backend.models.base import ConversationParams, LlmHistory, LLMStep, MediaSummary
from backend.utils.context_utils import LLMStepName
from backend.utils.llm_utils import handle_prompt_media_explanation, prompt_date_format
from dataiku.langchain.dku_llm import DKULLM
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain_core.prompt_values import PromptValue
from llm_assist.llm_tooling.tools import SqlRetrieverTool, get_all_dataset_descriptions
from llm_assist.logging import logger
from solutions.chains.generic_answers_chain import GenericAnswersChain
from solutions.chains.select_sql_agent import SelectSQLAgent
from solutions.prompts.conversations import ChatHistoryHandler


class DBRetrievalChain(GenericAnswersChain):
    def __init__(self, llm: DKULLM, chat_has_media: bool = False):
        self.__llm = llm
        self.__act_like_prompt = ""
        self.__system_prompt = ""
        self.__prompt_with_media_explanation = chat_has_media
        self.__qa_chain: Optional[LLMChain] = None
        self.__computed_prompt: Optional[PromptValue] = None
        self.__sql_query = ""
        self.__tables_used: List[str] = []
        self.__retrieval_query_agent = SelectSQLAgent()
        self.__use_db_retrieval = False

    @property
    def qa_chain(self) -> LLMChain:
        if self.__qa_chain is None:
            raise ValueError("QA chain is not initialized.")
        return self.__qa_chain

    @property
    def act_like_prompt(self) -> str:
        return self.__act_like_prompt

    @property
    def system_prompt(self) -> str:
        return self.__system_prompt

    @property
    def computed_prompt(self) -> PromptValue:
        if self.__computed_prompt is None:
            raise ValueError("Computed prompt is not initialized.")
        return self.__computed_prompt

    @property
    def sql_query(self) -> str:
        return self.__sql_query

    @property
    def tables_used(self) -> List[str]:
        return self.__tables_used

    @property
    def retrieval_query_agent(self) -> SelectSQLAgent:
        return self.__retrieval_query_agent

    @property
    def use_db_retrieval(self) -> bool:
        return self.__use_db_retrieval

    @property
    def llm(self) -> DKULLM:
        return self.__llm

    @property
    def chain_purpose(self) -> str:
        return LLMStepName.DB_ANSWER.value

    def load_role_and_guidelines_prompts(self, params: ConversationParams):
        act_like_prompt = self.webapp_config.get("db_prompt", "")
        system_prompt = self.webapp_config.get(
            "db_system_prompt",
            "Given the following specific context and the conversation between a human and an AI, please give a short answer to the question at the end. If you don't know the answer, just say that you don't know, don't try to make up an answer.",
        )

        user_profile = params.get("user_profile", None)
        system_prompt = self.append_user_profile_to_prompt(system_prompt=system_prompt, user_profile=user_profile)
        system_prompt = handle_prompt_media_explanation(system_prompt=system_prompt, has_media=self.__prompt_with_media_explanation)
        self.__act_like_prompt = act_like_prompt
        self.__system_prompt = system_prompt

    def create_db_retrieval_chain(self) -> LLMChain:
        datetime_now =  datetime.now().strftime(prompt_date_format)
        template = r"""
        Today's date and time: {datetime_now}
        {act_like_prompt}

        {system_prompt}

        Context: 
        ----
        {{context}}

        --- End of Context ---


        Chat history:
        {{history}}
        --- End of Chat history ---

        Human: {{input}}
        Assistant:""".format(datetime_now=datetime_now, act_like_prompt=self.act_like_prompt, system_prompt=self.system_prompt)
        qa_prompt = PromptTemplate(input_variables=["context", "history", "input"], template=template)
        chain = LLMChain(llm=self.llm, prompt=qa_prompt, memory=self.memory, verbose=True)
        return chain

    def create_db_retrieval_chain_on_but_not_used(self) -> LLMChain:
        datetime_now =  datetime.now().strftime(prompt_date_format)
        dataset_descriptions = get_all_dataset_descriptions()
        template = r"""
        Today's date and time: {datetime_now}
        {act_like_prompt}

        {system_prompt}
        
        Be aware that you are part of a team that can retrieve information from external data sources. 
        The data source description is:
        {dataset_descriptions}
        However, your teammate decided not make any query for the following reason:
        {{justification}}
        You do not need to mention this unless you are asked directly about it.
        - Do not attempt to write any SQL
        --- End of justification ---


        Chat history:
        {{history}}
        --- End of Chat history ---

        Human: {{input}}
        Assistant:""".format(
            datetime_now=datetime_now,
            act_like_prompt=self.act_like_prompt,
            dataset_descriptions=dataset_descriptions,
            system_prompt=self.system_prompt,
        )
        qa_prompt = PromptTemplate(input_variables=["justification", "history", "input"], template=template)
        chain = LLMChain(llm=self.llm, prompt=qa_prompt, memory=self.memory, verbose=True)
        return chain

    def create_chain(self, params: ConversationParams) -> LLMChain:
        if self.use_db_retrieval:
            self.__qa_chain = self.create_db_retrieval_chain()
        else:
            # 1st LLM decided not use the query not we need make the second LLM aware of this
            self.__qa_chain = self.create_db_retrieval_chain_on_but_not_used()
        return self.qa_chain

    def get_computing_prompt_step(self, params: ConversationParams) -> LLMStep:
        if self.use_db_retrieval:
            return LLMStep.COMPUTING_PROMPT_WITH_DB
        else:
            return LLMStep.COMPUTING_PROMPT_WITHOUT_RETRIEVAL

    def finalize_streaming(
        self, params: ConversationParams, question_context: Union[str, Dict[str, Any], List[str]]
    ) -> Dict[str, Any]:
        user_profile = params.get("user_profile", None)
        # Send sources and filters at the end of the streaming
        return self.get_as_json(question_context,
                                user_profile=user_profile,
                                uploaded_docs=params.get("media_summaries", None
            )
        )

    def finalize_non_streaming(
        self,
        params: ConversationParams,
        question_context: Union[str, Dict[str, Any], List[str]],
    ) -> Dict[str, Any]:
        return self.finalize_streaming(params=params, question_context=question_context)

    def get_querying_step(self, params: ConversationParams) -> LLMStep:
        if self.use_db_retrieval:
            step = LLMStep.QUERYING_LLM_WITH_DB
        else:
            step = LLMStep.QUERYING_LLM_WITHOUT_RETRIEVAL
        return step

    def __compute_prompt_for_db_but_disabled(
        self, conv_chain: LLMChain, user_question: str, justification: str, chat_history: list
    ) -> PromptValue:
        prompt: PromptValue
        inputs = conv_chain.prep_inputs(
            {"input": user_question, "history": self.memory, "justification": justification}
        )
        computed_prompt = conv_chain.prep_prompts(
            input_list=[{"input": user_question, "justification": justification, "history": inputs["history"]}]
        )

        logger.debug(computed_prompt)
        if computed_prompt:
            prompt = computed_prompt[0][0]
        return prompt

    def __exception_correction_loop(
        self,
        db_query: Union[Dict[str, Any], None],
        justification: str,
        user_question: str,
        attempt: int,
        chat_history: list,
        max_attempts: int = 3,
    ):
        sql_query = ""
        tables_used: List[str] = []
        records: Union[List[List[Dict[str, str]]], List[Dict[str, List[Any]]]] = []
        sql_tool = SqlRetrieverTool()
        logger.debug(f"Correction attempt no. {attempt + 1}")
        context = ""
        if attempt >= max_attempts or db_query is None:
            logger.error("Unable to read from SQL table after maximum retries")
            context = f"""
            Error while reading from SQL table after {max_attempts} attempts
            {self.retrieval_query_agent.previous_sql_errors}
            The SQL table description is:
            {get_all_dataset_descriptions()}
            The following attempts were made:
            {self.retrieval_query_agent.formatted_errors}
            """
            return context, sql_query, records, tables_used
        failed_response = {**db_query, "justification": justification}
        db_query, justification = self.retrieval_query_agent.get_retrieval_query(
            self.llm, chat_history, user_question, failed_response=failed_response
        )
        try:
            if db_query is not None:
                context, sql_query, records, tables_used = sql_tool._run(db_query)
            else:
                # TODO: Handle this case as the db_on_but_disabled method
                context = "No Need for database query"
            return context, sql_query, records, tables_used
        except Exception as e:
            logger.error(f"Unable to read from SQL table on first attempt {e}")
            context = f"Error when reading from SQL table {e}."
            db_query = db_query or {}
            failed_response = {**db_query, "justification": justification}
            failed_response_str = str(failed_response)
            self.retrieval_query_agent.previous_sql_errors.append(
                {"response": failed_response_str, "query": sql_query, "error": str(e)}
            )
            attempt += 1
            return self.__exception_correction_loop(
                db_query=db_query,
                justification=justification,
                user_question=user_question,
                chat_history=chat_history,
                attempt=attempt,
            )

    def __prep_db_question_context(self, records: List[Dict[str, List[Any]]], sql_query: str):
        columns = []
        if len(records) > 0:
            columns = [{"name": r, "label": r, "field": r, "align": "left"} for r in records[0].keys()]
        question_context = {"rows": records, "columns": columns, "query": sql_query}
        return question_context

    def __compute_prompt_for_db(
        self, conv_chain: LLMChain, user_question: str, db_query: dict, justification: str, chat_history: list
    ) -> Tuple[PromptValue, str, Dict[Any, Any], List]:
        sql_query = ""
        records: List[List[Dict[str, str]]] = []
        question_context = {}
        self.retrieval_query_agent.previous_sql_errors = []
        logger.debug("Running DB retrieval.")
        sql_tool = SqlRetrieverTool()
        context = ""
        try:
            context, sql_query, records, tables_used = sql_tool._run(db_query)
        except Exception as e:
            logger.error(f"Unable to read from SQL table on first attempt {e}")
            context = f"Error when reading from SQL table {e}."
            logger.debug("Entering exception correction loop")
            failed_response = {**db_query, "justification": justification}
            failed_response_str = str(failed_response)
            self.retrieval_query_agent.previous_sql_errors.append(
                {"response": failed_response_str, "query": sql_query, "error": str(e)}
            )
            context, sql_query, records, tables_used = self.__exception_correction_loop(
                db_query=db_query,
                justification=justification,
                user_question=user_question,
                chat_history=chat_history,
                attempt=0,
            )
        finally:
            logger.debug(f"Query creation completed. Context: {context}")
            inputs = conv_chain.prep_inputs({"input": user_question, "history": self.memory, "context": context})
            computed_prompt = conv_chain.prep_prompts(
                input_list=[{"input": user_question, "context": context, "history": inputs["history"]}]
            )
            logger.debug(computed_prompt)
            question_context = self.__prep_db_question_context(records, sql_query)  # type: ignore
        return computed_prompt[0][0], sql_query, question_context, tables_used

    def create_computed_prompt(
        self,
        params: ConversationParams,
    ) -> Tuple[PromptValue, Dict[str, Any]]:
        start_time = time.time()
        user_query = params.get("user_query", "")
        db_query = params.get("db_query", {})
        justification = params.get("justification", "")
        chat_history = params.get("chat_history", [])

        question_context: Dict[str, Any] = {}
        if self.use_db_retrieval:
            self.__computed_prompt, self.__sql_query, question_context, self.__tables_used = (
                self.__compute_prompt_for_db(
                    conv_chain=self.qa_chain,
                    user_question=user_query,
                    db_query=db_query,
                    justification=justification,
                    chat_history=self.format_history(chat_history),
                )
            )
            logger.debug(f"Time ===> taken by Computing prompt for retrieval: {(time.time() - start_time):.2f} secs")

        else:
            self.__computed_prompt = self.__compute_prompt_for_db_but_disabled(
                conv_chain=self.qa_chain,
                user_question=user_query,
                justification=justification,
                chat_history=self.format_history(chat_history),
            )
            logger.debug(
                f"Time ===> taken by Computing prompt for conversational: {(time.time() - start_time):.2f} secs"
            )
        logger.debug(f"Final prompt:  {self.computed_prompt.to_string() if self.computed_prompt else 'No prompt'}")
        return self.computed_prompt, question_context

    def get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any], List[str]],
        user_profile: Optional[Dict[str, Any]] = None,
        uploaded_docs: Optional[List[MediaSummary]] = None,
    ) -> Dict[str, Any]:
        llm_context: Dict[str, Any] = {}

        if len(self.sql_query) > 0:
            llm_context["dataset_context"] = {
                "sql_retrieval_table_list": self.webapp_config.get("sql_retrieval_table_list"),
                "tables_used": self.tables_used,
                "sql_query": self.sql_query.replace("\n", "").replace('\\"', '"'),
            }
        if user_profile:
            llm_context["user_profile"] = user_profile

        if isinstance(generated_answer, str):
            return {
                "answer": generated_answer,
                "sources": [],
                "filters": None,
                "knowledge_bank_selection": [],
            }
        llm_context["uploaded_docs"] = [{"original_file_name": str(uploaded_docs.get("original_file_name")),
                                         "metadata_path": str(uploaded_docs.get("metadata_path"))} for uploaded_docs in uploaded_docs] \
                                         if uploaded_docs else []
        if isinstance(generated_answer, dict):
            answer = generated_answer.get("answer", "")
            tables_used_str = (
                ", ".join(self.tables_used) if isinstance(self.tables_used, list) else str(self.tables_used)
            )
            # sample without answer key in it.
            sample = generated_answer.copy()
            sample.pop("answer", "")
            return {
                "answer": answer,
                "sources": [{"sample": sample, "metadata": {"source_title": tables_used_str}}],
                "filters": None,
                "llm_context": llm_context,
            }
        logger.error(f"Generated answer type not supported. This should not happen. {generated_answer}")
        return {}

    # TODO: correct retrieval query part - to be handled in different loops
    def create_query_from_history_and_update_params(
        self, chat_history: List[LlmHistory], user_query: str, params: ConversationParams
    ) -> ConversationParams:
        chat_history_str = None
        chat_history_handler = ChatHistoryHandler()
        chat_history_str = chat_history_handler.format_chat_history(chat_history=chat_history)
        self.retrieval_query_agent.get_retrieval_graph(
            llm=self.llm, chat_history=chat_history_str, user_input=user_query, conversation_params=params
        )
        retrieval_query, justification = self.retrieval_query_agent.get_retrieval_query(
            llm=self.llm, chat_history=chat_history_str, user_input=user_query
        )
        params["justification"] = justification

        params["db_query"] = retrieval_query
        logger.debug(
            f"get_retrieval_query performed for db_query with: [{user_query}], computed db_query is [{params['db_query']}]"
        )

        self.__use_db_retrieval = False if params["db_query"] is None else True
        logger.debug(f"use_db_retrieval: {self.use_db_retrieval}")
        return params
