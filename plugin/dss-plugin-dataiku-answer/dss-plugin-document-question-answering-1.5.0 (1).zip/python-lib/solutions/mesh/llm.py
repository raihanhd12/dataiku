import json
import re
from dataclasses import dataclass, fields
from typing import Any, List, Optional, Union

import dataiku
from backend.utils.context_utils import LLMStepMetrics, add_llm_step_metrics
from backend.utils.dataiku_api import dataiku_api
from dataiku.core.intercom import DSSClient, TicketProxyingDSSClient
from dataikuapi.dss.llm import (
    DSSLLM,
    DSSLLMCompletionQuery,
    DSSLLMImageGenerationQuery,
    DSSLLMImageGenerationResponse,
    DSSLLMStreamedCompletionChunk,
    _SSEClient,
)
from dataikuapi.utils import DataikuException
from llm_assist.logging import logger


@dataclass
class CompletionResponse:
    ok: bool
    finishReason: str
    predictedClassProbas: Optional[List[float]] = None
    fromCache: bool = False
    promptTokens: int = 0
    completionTokens: int = 0
    totalTokens: int = 0
    tokenCountsAreEstimated: bool = False
    estimatedCost: float = 0.0
    text: Optional[str] = None
    errorMessage: Optional[str] = ""
    # ensure to include only known fields 
    @classmethod
    def from_dict(cls, data: dict) -> 'CompletionResponse':
        field_names = {f.name for f in fields(cls)}
        filtered_data = {k: v for k, v in data.items() if k in field_names}
        return cls(**filtered_data)


@dataclass
class StreamedFinishedCompletionChunk:
    finishReason: str
    promptTokens: int = 0
    completionTokens: int = 0
    totalTokens: int = 0
    tokenCountsAreEstimated: bool = False
    estimatedCost: float = 0.0
    errorMessage: Optional[str] = ""
    # ensure to include only known fields 
    @classmethod
    def from_dict(cls, data: dict) -> 'StreamedFinishedCompletionChunk':
        field_names = {f.name for f in fields(cls)}
        filtered_data = {k: v for k, v in data.items() if k in field_names}
        return cls(**filtered_data)


def parse_error_messages(error_as_str: Union[str, DataikuException]) -> str:
    dicts = re.findall(r"\{[^{}]*\}", str(error_as_str))
    if len(dicts) > 0:
        message = json.loads(dicts[0])
        if "message" in message:
            return f" Error message: {message['message']}"
    logger.debug(f"Error message from LLM couldn't be parsed: {error_as_str}")
    return ""


class DSSLLMAnswersStreamedCompletionFooter:
    def __init__(self, data: dict, llm_step: LLMStepMetrics) -> None:
        self.llm_step = llm_step
        validated_chunk = self.validate_streamed_answers_api_response(data)
        self.update_token_counts(validated_chunk)
        self.data = validated_chunk

    def validate_streamed_answers_api_response(self, footer_chunk: Any) -> StreamedFinishedCompletionChunk:
        if isinstance(footer_chunk, dict):
            validated_chunk: StreamedFinishedCompletionChunk = StreamedFinishedCompletionChunk.from_dict(footer_chunk)
            if errorMessage := validated_chunk.errorMessage:
                logger.error(f"Error message from LLM: {errorMessage}")
            # with agents, finish_reason may be unknown, removed finish_reason != "stop"
            return validated_chunk
        raise Exception(f"Unexpected LLM footer_chunk format. footer_chunk:  {footer_chunk}")

    def update_token_counts(self, validated_chunk: StreamedFinishedCompletionChunk) -> None:
        self.llm_step.stop_timer()
        add_llm_step_metrics(
            LLMStepMetrics(
                **self.llm_step.to_dict(),
                prompt_tokens=validated_chunk.promptTokens,
                completion_tokens=validated_chunk.completionTokens,
                total_tokens=validated_chunk.totalTokens,
                token_counts_are_estimated=validated_chunk.tokenCountsAreEstimated,
                # estimated_cost = self.data.estimatedCost
            )
        )

   


class AnswersDSSLLMCompletionQuery(DSSLLMCompletionQuery):
    def __init__(self, llm: DSSLLM) -> None:
        super().__init__(llm)
        max_llm_tokens: int = int(dataiku_api.webapp_config.get("max_llm_tokens", 2048))
        self.settings["maxOutputTokens"] = max_llm_tokens

    def validate_answers_api_response(
        self, llm_response: Any
    ) -> CompletionResponse:
        llm_error_message = f"The LLM responded with an error. "
        if isinstance(llm_response, dict) and "responses" in llm_response:
            completion_response = CompletionResponse.from_dict(llm_response["responses"][0])
            finish_reason = completion_response.finishReason
            is_ok = completion_response.ok
            text = completion_response.text
            if error_message := completion_response.errorMessage:
                logger.error(f"Error message from LLM: {error_message}")
                message = parse_error_messages(error_message)
                completion_response.text = ""
                completion_response.errorMessage = llm_error_message + message
            # with agents, finish_reason may be unknown, removed finish_reason != "stop"
            elif not is_ok or not text:
                logger.error(f"LLM did not return OK. Finish reason: {finish_reason}")
                completion_response.text = ""
                completion_response.errorMessage = llm_error_message
            return completion_response
        logger.exception(f"Unexpected LLM response format. Response {llm_response}")
        raise ValueError(f"Unexpected LLM response format. Response {llm_response}")

    def execute(self, llm_step: LLMStepMetrics) -> CompletionResponse:
        step_name: str = llm_step.step_name
        queries = {"queries": [self.cq], "settings": self._settings, "llmId": self.llm.llm_id}
        try:
            response = self.llm.client._perform_json(
                "POST", "/projects/%s/llms/completions" % (self.llm.project_key), body=queries
            )
            validated_response: CompletionResponse = self.validate_answers_api_response(response)

        except DataikuException as e:
            logger.exception(f"LLM step {step_name} failed with DataikuException: {e}")
        except Exception as e:
            logger.exception(f"LLM step {step_name} failed with the Exception: {e}")
        llm_step.stop_timer()
        add_llm_step_metrics(
            LLMStepMetrics(
                **llm_step.to_dict(),
                from_cache=validated_response.fromCache,
                prompt_tokens=validated_response.promptTokens,
                completion_tokens=validated_response.completionTokens,
                total_tokens=validated_response.totalTokens,
                token_counts_are_estimated=validated_response.tokenCountsAreEstimated,
                estimated_cost=validated_response.estimatedCost,
            )
        )
        using_cache: bool = bool(validated_response.fromCache)
        logger.debug(f"LLM completion step {llm_step} using a cached response : {using_cache}")
        return validated_response

    def execute_streamed(self, llm_step: LLMStepMetrics):
        error_message = "LLM did not respond correctly."
        step_name: str = llm_step.step_name
        request = {"query": self.cq, "settings": self.settings, "llmId": self.llm.llm_id}
        try:
            ret = self.llm.client._perform_raw(
                "POST", "/projects/%s/llms/streamed-completion" % (self.llm.project_key), body=request
            )
            sseclient = _SSEClient(ret.raw)
            for evt in sseclient.iterevents():
                if evt.event == "completion-chunk":
                    yield DSSLLMStreamedCompletionChunk(json.loads(evt.data))
                else:
                    footer_chunk = json.loads(evt.data)
                    yield DSSLLMAnswersStreamedCompletionFooter(footer_chunk, llm_step)

        except DataikuException as e:
            logger.exception(f"LLM step {step_name} failed with DataikuException: {e}")
            message = parse_error_messages(e)
            error_message += message
            yield DSSLLMStreamedCompletionChunk({"text": error_message})
            yield DSSLLMAnswersStreamedCompletionFooter(
                {"finishReason": "error", "errorMessage": error_message}, llm_step
            )
        except Exception as e:
            logger.exception(f"LLM step {step_name} failed with Exception: {e}")
            yield DSSLLMStreamedCompletionChunk({"text": error_message})
            yield DSSLLMAnswersStreamedCompletionFooter(
                {"finishReason": "error", "errorMessage": error_message}, llm_step
            )


class AnswerDSSLLMImageGenerationQuery(DSSLLMImageGenerationQuery):
    def execute(self, llm_step: LLMStepMetrics) -> DSSLLMImageGenerationResponse:
        try:
            ret = self.llm.client._perform_json(
                "POST", "/projects/%s/llms/images" % (self.llm.project_key), body=self.gq
            )
        except DataikuException as e:
            raise Exception(f"LLM step {llm_step.step_name} failed with DataikuException: {e}")
        except Exception as e:
            raise Exception(f"LLM step {llm_step.step_name} failed with Exception: {e}")
        llm_step.stop_timer()
        add_llm_step_metrics(llm_step)
        return DSSLLMImageGenerationResponse(ret)


class AnswersDSSLLM(DSSLLM):
    def __init__(self, llm_id: str):
        project_key: str = dataiku_api.default_project_key
        client: Union[DSSClient, TicketProxyingDSSClient] = dataiku.api_client()
        super().__init__(client, project_key, llm_id)

    def new_completion(self) -> AnswersDSSLLMCompletionQuery:
        return AnswersDSSLLMCompletionQuery(self)


class AnswersDSSLLMImage(DSSLLM):
    def __init__(self, llm_id: str):
        project_key: str = dataiku_api.default_project_key
        client: Union[DSSClient, TicketProxyingDSSClient] = dataiku.api_client()

        super().__init__(client, project_key, llm_id)

    def new_images_generation(self) -> AnswerDSSLLMImageGenerationQuery:
        return AnswerDSSLLMImageGenerationQuery(self)
