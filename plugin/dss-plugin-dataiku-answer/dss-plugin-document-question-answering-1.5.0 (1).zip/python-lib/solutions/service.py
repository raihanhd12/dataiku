import time
from datetime import datetime
from typing import Any, Dict, List, Optional

from backend.db.conversation import CONVERSATION_DEFAULT_NAME
from backend.db.sql.sql_timing import log_query_time
from backend.models.base import (
    ConversationParams,
    ConversationType,
    LlmHistory,
    MediaSummary,
    RetrieverMode,
)
from backend.utils.context_utils import TIME_FORMAT, LLMStepMetrics, LLMStepName, reset_llm_step_metrics
from backend.utils.dataiku_api import dataiku_api
from backend.utils.knowledge_banks_params import KnowledgeBanksParams
from backend.utils.llm_utils import get_llm_capabilities
from langchain.memory import ConversationBufferMemory
from llm_assist.llm_api_handler import llm_setup
from llm_assist.logging import logger
from solutions.chains.conversation_title import ConversationTitleChainHandler
from solutions.chains.db_retrieval_chain import DBRetrievalChain

# from solutions.chains.doc_rag_chain import DocumentRagChain
from solutions.chains.generic_answers_chain import GenericAnswersChain
from solutions.chains.image_generation_chain import ImageGenerationChain
from solutions.chains.image_generation_decision_chain import ImageGenerationDecisionChain
from solutions.chains.kb_retrieval_chain import KBRetrievalChain
from solutions.chains.media_qa_chain import MediaQAChain
from solutions.chains.no_retrieval_chain import NoRetrievalChain
from solutions.mesh.llm import AnswersDSSLLM, CompletionResponse
from solutions.prompts.conversation_title import CONVERSATION_TITLE_PROMPT
from solutions.prompts.conversations import ChatHistoryHandler

MEDIA_CONVERSATION_START_TAG = "_START_MEDIA_QA_CONVERSATION_"


class LLM_Question_Answering:
    """LLM_Question_Answering: A class to facilitate the question-answering process using LLM model"""

    def __init__(self, llm):
        # Constructor parameters:
        self.project = dataiku_api.default_project
        self.llm = llm
        self.memory = ConversationBufferMemory(input_key="input", return_messages=True)
        self.webapp_config = dataiku_api.webapp_config
        # Parameters:
        self.retrieval_mode = self.webapp_config.get("retrieval_mode")
        if self.retrieval_mode == "":
            raise Exception("retrieval_mode must be provided")
        self.chat_has_media = False
        # Initialize knowledge banks parameters once for all
        self.kbs_params = KnowledgeBanksParams()
        # Chains and chain handlers:
        self.conversation_title_template = ConversationTitleChainHandler(CONVERSATION_TITLE_PROMPT).get_prompt(llm)
        self.chat_history_handler = ChatHistoryHandler()

    def __update_memory(self, chat_history: List[LlmHistory]) -> None:
        self.memory.clear()
        for item in chat_history:
            inputs = {"input": item["input"]}
            outputs = {"output": item["output"]}
            if "generated_media_by_ai" in item["output"]:
                self.chat_has_media = True
            logger.debug(f"The memory inputs {inputs}. The memory outputs {outputs}")
            self.memory.save_context(inputs, outputs)

    def get_answer_and_sources(  # noqa: PLR0917 too many positional arguments
        self,
        query: str,
        conversation_type: ConversationType,
        chat_history: List[LlmHistory] = [],
        filters: Optional[Dict[str, List[Any]]] = None,
        chain_type: Optional[str] = None,
        media_summaries: Optional[List[MediaSummary]] = None,
        previous_media_summaries: Optional[List[MediaSummary]] = None,
        retrieval_enabled: bool = False,
        user_profile: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Extracts the answer and its corresponding sources for a given prompt.

        Args:
            query (str): The user query.
            query_index: int: The index of the query within the conversation.
            chat_history (List[LlmHistory]): A list of prior interactions (optional). Each interaction
                is a dictionary with the question and response.
            filters (Optional[Dict[str, List[Any]]]): A dictionary of filters to apply to the knowledge bank.
            file_path Optional[str]: The file path uploaded into a managed folder
            chain_type Optional[str]: The file type of an uploaded file. This indicates how it should be handled
            metadata_path Optional[str]: The json file path of uploaded documents containing any extracted text


        Returns:
            Dict[str, Union[str, Dict[str, Any]]]: A dictionary containing:
                - 'answer' (str): The generated answer to the prompt.
                - 'sources' (List[Dict]): A list of dict:
                    - 'excerpt' (str): The content of the source.
                    - 'metadata' (Dict[str, str]): Additional metadata about the source.
        """

        logger.debug("Time ===>: starting tracking time: Generating response")
        conversation_params: ConversationParams = {
            "user_query": query,
            "chat_history": chat_history,
            "chain_type": chain_type,
            "media_summaries": media_summaries,
            "previous_media_summaries": previous_media_summaries,
            "retrieval_enabled": retrieval_enabled,
            "knowledge_bank_selection": [],
            "use_db_retrieval": False,
            "global_start_time": time.time(),  # Capture start time
            "justification": "",
            "user_profile": user_profile,
            "self_service_decision": None,
            "chain_purpose": LLMStepName.UNKNOWN.value,
        }
        logger.debug(f"""retrieval_mode is set to : {self.retrieval_mode}
        Conversation type is set to: {conversation_type}
        Chain type is set to: {chain_type}""")
        response = None
        if conversation_type is not None:
            logger.debug(f"conversation_type is set to : {conversation_type}")
        self.__update_memory(chat_history=conversation_params["chat_history"])
        llm_capabilities = get_llm_capabilities()

        if query != MEDIA_CONVERSATION_START_TAG:
            reset_llm_step_metrics()

        if llm_capabilities.get("image_generation", False) and query != MEDIA_CONVERSATION_START_TAG:
            logger.debug("Image generation is enabled")

            img_system_prompt = self.webapp_config.get("image_generation_system_prompt")
            img_gen_decision_chain = ImageGenerationDecisionChain(
                llm=self.llm, chat_history=chat_history, system_prompt=img_system_prompt
            )
            decision_output = img_gen_decision_chain.get_decision_as_json(
                user_query=query, step_name=LLMStepName.DECISION_IMAGE_GENERATION.value
            )
            logger.debug(f"Image generation decision chain output: {decision_output}")
            generate_image = decision_output.get("decision")
            generated_query = decision_output.get("query")
            referred_image = decision_output.get("referred_image")
            if generate_image:
                response = ImageGenerationChain(
                    user_query=generated_query,
                    referred_image=referred_image,
                    user_profile=user_profile,
                    llm=self.llm,
                ).run_image_generation_query()
                return response
            # If image generation is not required, continue with the normal flow and ignore media in the user profile
            if user_profile and user_profile.get("media"):
                user_profile.pop("media", None)
            if user_profile and user_profile.get("generated_media_info"):
                user_profile.pop("generated_media_info", None)

        qa_chain: GenericAnswersChain
        if query == MEDIA_CONVERSATION_START_TAG:
            logger.debug("Starting media QA conversation")
            response = MediaQAChain(media_summaries).start_media_qa_chain(user_profile, False if chat_history else True)
            return response
        if retrieval_enabled and self.retrieval_mode == RetrieverMode.KB.value:
            logger.debug("KB retrieval enabled")
            qa_chain = KBRetrievalChain(self.llm, query=query, filters=filters, chat_has_media=self.chat_has_media)
        elif retrieval_enabled and self.retrieval_mode == RetrieverMode.DB.value:
            logger.debug("DB retrieval enabled")
            qa_chain = DBRetrievalChain(self.llm, chat_has_media=self.chat_has_media)
        else:
            logger.debug("No retrieval enabled")
            qa_chain = NoRetrievalChain(self.llm, chat_has_media=self.chat_has_media)

        conversation_params = qa_chain.create_query_from_history_and_update_params(
            chat_history, query, conversation_params
        )
        if (
            retrieval_enabled
            # and conversation_type == ConversationType.GENERAL
            and self.retrieval_mode == RetrieverMode.KB.value
            and not conversation_params["knowledge_bank_selection"]
        ):
            qa_chain = NoRetrievalChain(self.llm)
        conversation_params["chain_purpose"] = qa_chain.chain_purpose
        response = qa_chain.run_completion_query(conversation_params, self.memory)
        return response

    @log_query_time
    def get_conversation_title(self, query: str, answer: str, user_profile: Optional[Dict[str, Any]] = None) -> str:
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        prompt_message = self.conversation_title_template.invoke(
            dict(query=query, answer=answer, user_profile=user_profile)
        ).to_string()
        llm_id = self.webapp_config.get("title_llm_id", None) or self.llm.llm_id
        logger.debug(f"Using LLM ID for title generation: {llm_id}")
        completion = AnswersDSSLLM(llm_id).new_completion()
        completion.with_message(prompt_message)
        current_step = LLMStepMetrics(step_name=LLMStepName.CONVERSATION_TITLE.value, step_start_time=start_time)
        try:
            resp: CompletionResponse = completion.execute(current_step)
            text = str(resp.text)
            if not text and resp.errorMessage:
                raise Exception(resp.errorMessage)
        except Exception as e:
            raise Exception(f"Error when calling LLM API: {e}.")

        json_answer: str = (
            NoRetrievalChain(self.llm)
            .get_as_json(text, user_profile=user_profile)
            .get("answer", CONVERSATION_DEFAULT_NAME)
        )
        return json_answer


llm_qa = LLM_Question_Answering(llm_setup.get_llm())
