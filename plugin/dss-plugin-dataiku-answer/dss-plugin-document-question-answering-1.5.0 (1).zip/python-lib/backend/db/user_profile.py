import json
from datetime import datetime, timezone
from typing import Any, Dict, Literal, Optional

import pandas as pd
from backend.db.sql.dataset_schemas import ANSWERS_DATASETS_METADATA, USER_PROFILE_DATASET_CONF_ID
from backend.db.sql.queries import (
    DIALECT_VALUES,
    InsertQueryBuilder,
    Operator,
    UpdateQueryBuilder,
    WhereCondition,
    _get_where_and_cond,
    columns_in_uppercase,
    get_post_queries,
)
from backend.db.sql.sql_timing import log_query_time
from backend.utils.dataiku_api import dataiku_api
from backend.utils.date_utils import from_datetime_to_dss_string_date
from backend.utils.user_profile_utils import update_user_profile_generated_media_info
from dataiku import Dataset, SQLExecutor2
from dataiku.sql import Column, SelectQuery, toSQL
from llm_assist.logging import logger
from werkzeug.exceptions import BadRequest


class UserProfileSQL:
    def __init__(self):
        self.columns = ANSWERS_DATASETS_METADATA[USER_PROFILE_DATASET_CONF_ID]["columns"]
        self.config = dataiku_api.webapp_config
        self.dataset_name = self.config.get(USER_PROFILE_DATASET_CONF_ID, None)
        self.__verify()
        self.dataset = Dataset(project_key=dataiku_api.default_project_key, name=self.dataset_name)
        self.__init_dataset()
        self.executor = SQLExecutor2(dataset=self.dataset)
        self.is_upper = False
        self.get_column_names()


    def __verify(self):
        if self.dataset_name is None or self.dataset_name == "":
            logger.error("User profile Dataset name should not be null")
            raise ValueError("User profile Dataset name should not be null")
        self.__check_dataset_exists()
        self.__check_supported_dialect()

    def __check_dataset_exists(self):
        project = dataiku_api.client.get_project(dataiku_api.default_project_key)
        data = project.list_datasets()
        datasets = [item.name for item in data]
        logger.debug(f"Searching for {self.dataset_name} in this project datasets: {datasets}")
        if self.dataset_name in datasets:
            return True
        else:
            logger.error("User Profile dataset does not exist")
            raise ValueError("User Profile dataset does not exist")

    def __check_supported_dialect(self):
        dataset = Dataset(project_key=dataiku_api.default_project_key, name=self.dataset_name)
        dataset_type = dataset.get_config().get("type")
        result = dataset_type in DIALECT_VALUES
        if result:
            return
        else:
            logger.error(f"Dataset Type {dataset_type} is not supported")
            raise ValueError(f"Dataset Type {dataset_type} is not supported")

    def __init_dataset(self):
        try:
            self.dataset.read_schema(raise_if_empty=True)
        except Exception as e:
            logger.info("Initializing the user profile dataset schema")
            df = self.get_init_df()
            df["last_updated"] = pd.to_datetime(df["last_updated"])
            self.dataset.write_with_schema(df=df)

    def get_init_df(self):
        data = {col: [] for col in self.columns}
        return pd.DataFrame(data=data, columns=self.columns, dtype=str)

    def col(self, col_name:str) -> str:
        if self.is_upper:
            return col_name.upper()
        return col_name

    def get_column_names(self):
        if columns_in_uppercase(self.dataset):
            self.is_upper = True
            self.columns = [col.upper() for col in self.columns]

    def execute(
        self,
        query_raw,
        format_: Literal["dataframe", "iter"] = "dataframe",
    ):
        try:
            query = toSQL(query_raw, dataset=self.dataset)
        except Exception as err:
            raise BadRequest(f"Error when generating SQL query: {err}")

        if format_ == "dataframe":
            try:
                query_result = self.executor.query_to_df(query=query).fillna("")
                return query_result
            except Exception as err:
                raise BadRequest(f"Error when generating SQL query: {err}")
        elif format_ == "iter":
            try:
                query_result = self.executor.query_to_iter(query=query).iter_tuples()
                return query_result
            except Exception as err:
                raise BadRequest(f"Error when executing SQL query: {err}")

    def execute_commit(self):
        return

    @log_query_time
    def get_user_profile(self, auth_identifier: str) -> Optional[Dict]:
        eq_cond = [
            WhereCondition(column=self.col("user"), value=auth_identifier,
                           operator=Operator.EQ)

        ]
        where_cond = _get_where_and_cond(eq_cond)
        select_query = SelectQuery().select_from(
            self.dataset).select(Column(self.col("profile"))).where(where_cond)
        try:
            result = self.execute(select_query, format_="dataframe")
            if not result.empty:
                profile_str = result.iloc[0].to_dict()[self.col("profile")]
                profile_dict = dict(json.loads(profile_str))
                return profile_dict
            else:
                logger.debug(f"No profile found for user {auth_identifier}")
                return None
        except Exception as err:
            logger.error(err)
            raise BadRequest(f"Error when executing SQL query: {err}")

    @log_query_time
    def add_user_profile(
        self,
        user: str,
        profile: Dict,
    ):
        record_value = [
            user,
            json.dumps(profile, ensure_ascii=False),
            from_datetime_to_dss_string_date(datetime.now(timezone.utc)),
        ]
        insert_query = InsertQueryBuilder(self.dataset).add_columns(self.columns).add_values(values=[record_value]).build()
        try:
            self.executor.query_to_df(insert_query, post_queries=get_post_queries(self.dataset))
        except Exception as err:
            logger.error(err)
            raise BadRequest(f"Error when executing SQL query: {err}")

    @log_query_time
    def update_user_profile(self, user: str, profile: Dict):
        eq_cond = [
            WhereCondition(column=self.col("user"), value=user, operator=Operator.EQ),
        ]
        update_query = (UpdateQueryBuilder(self.dataset)
                        .add_set_cols(
            [
                (self.col("profile"), json.dumps(profile, ensure_ascii=False)),
                (self.col("last_updated"), from_datetime_to_dss_string_date(datetime.now(timezone.utc)))
            ]
        )
            .add_conds(eq_cond)
            .build()
        )
        try:
            self.executor.query_to_df(update_query, post_queries=get_post_queries(self.dataset))
        except Exception as err:
            logger.error(err)
            raise BadRequest(f"Error when executing SQL query: {err}")

    def update_generated_images_count_in_db(
        self, user: str, user_profile: Dict[str, Any], num_generated_images: int, config: Dict[str, str]
    ) -> Dict[str, Any]:
        # Extract the maximum images allowed per user per week from the config
        max_images_per_week = int(config.get("max_images_per_user_per_week", 0))
        logger.debug(f"Max images per week: {max_images_per_week}. Number of images generated: {num_generated_images}")
        # Proceed only if there is a valid max image count specified
        if max_images_per_week > 0 and num_generated_images > 0:
            user_profile_exists = True
            if user_profile.get("new_user_profile", False):
                user_profile_exists = False
            user_profile = update_user_profile_generated_media_info(user_profile, num_generated_images)
            if user_profile_exists:
                # Update the user profile with the new media data
                self.update_user_profile(user, user_profile)
            else:
                # Create a new user profile with the generated media data
                self.add_user_profile(
                    user, {"generated_media_info": user_profile["generated_media_info"]}
                )
        return user_profile


user_profile_sql_manager = UserProfileSQL()
