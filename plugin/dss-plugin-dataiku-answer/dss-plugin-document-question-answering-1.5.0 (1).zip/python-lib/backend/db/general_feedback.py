from datetime import datetime
from typing import Literal, Optional

import pandas as pd
from backend.db.sql.dataset_schemas import ANSWERS_DATASETS_METADATA, GENERAL_FEEDBACK_DATASET_CONF_ID
from backend.db.sql.queries import DIALECT_VALUES, InsertQueryBuilder, columns_in_uppercase, get_post_queries
from backend.db.sql.sql_timing import log_query_time
from backend.utils.dataiku_api import dataiku_api
from dataiku import Dataset, SQLExecutor2
from dataiku.sql import toSQL
from llm_assist.logging import logger
from werkzeug.exceptions import BadRequest


class GeneralFeedbackSQL:
    def __init__(self):
        self.columns = ANSWERS_DATASETS_METADATA[GENERAL_FEEDBACK_DATASET_CONF_ID]["columns"]
        self.config = dataiku_api.webapp_config
        self.dataset_name = self.config.get(GENERAL_FEEDBACK_DATASET_CONF_ID, None)
        if not self.config.get("allow_general_feedback", False):
            return
        self.__verify()
        self.dataset = Dataset(project_key=dataiku_api.default_project_key, name=self.dataset_name)
        self.__init_dataset()
        self.executor = SQLExecutor2(dataset=self.dataset)
        self.get_column_names()

    def __verify(self):
        if self.dataset_name is None or self.dataset_name == "":
            logger.error("Feedbacks Dataset name should not be null")
            raise ValueError("Feedbacks Dataset name should not be null")
        self.__check_dataset_exists()
        self.__check_supported_dialect()

    def __check_dataset_exists(self):
        project = dataiku_api.client.get_project(dataiku_api.default_project_key)
        data = project.list_datasets()
        datasets = [item.name for item in data]
        logger.debug(f"Searching for {self.dataset_name} in this project datasets: {datasets}")
        if self.dataset_name in datasets:
            return True
        else:
            logger.error("Feedbacks dataset does not exist")
            raise ValueError("Feedbacks dataset does not exist")

    def __check_supported_dialect(self):
        # TODO: Limit dialects here is needed
        dataset = Dataset(project_key=dataiku_api.default_project_key, name=self.dataset_name)
        dataset_type = dataset.get_config().get("type")
        result = dataset_type in DIALECT_VALUES
        if result:
            return
        else:
            logger.error(f"Dataset Type {dataset_type} is not supported")
            raise ValueError(f"Dataset Type {dataset_type} is not supported")

    def __init_dataset(self):
        try:
            self.dataset.read_schema(raise_if_empty=True)
        except Exception as e:
            logger.info("Initializing the feedback dataset schema")
            df = self.get_init_df()
            self.dataset.write_with_schema(df=df)

    def get_column_names(self):
        if columns_in_uppercase(self.dataset):
            self.columns = [col.upper() for col in self.columns]

    def get_init_df(self):
        data = {col: [] for col in self.columns}
        return pd.DataFrame(data=data, columns=self.columns, dtype=str)

    def execute(
        self,
        query_raw,
        format_: Literal["dataframe", "iter"] = "dataframe",
    ):
        try:
            query = toSQL(query_raw, dataset=self.dataset)
        except Exception as err:
            raise BadRequest(f"Error when generating SQL query: {err}")

        if format_ == "dataframe":
            try:
                query_result = self.executor.query_to_df(query=query).fillna("")
                return query_result
            except Exception as err:
                raise BadRequest(f"Error when generating SQL query: {err}")
        elif format_ == "iter":
            try:
                query_result = self.executor.query_to_iter(query=query).iter_tuples()
                return query_result
            except Exception as err:
                raise BadRequest(f"Error when executing SQL query: {err}")

    def execute_commit(self):
        return

    @log_query_time
    def add_feedback(
        self,
        timestamp: datetime,
        user: str,
        message: str,
        knowledge_bank_id: Optional[str] = None,
        llm_id: Optional[str] = None,
    ):
        record_value = [
            timestamp.isoformat(),
            user,
            message,
            knowledge_bank_id if knowledge_bank_id is not None else "",
            llm_id if llm_id is not None else "",
        ]
        insert_query = (
            InsertQueryBuilder(self.dataset)
            .add_columns(self.columns)
            .add_values(values=[record_value])
            .build()
        )
        self.executor.query_to_df(insert_query, post_queries=get_post_queries(self.dataset))


feedbacks_sql_manager = GeneralFeedbackSQL()
