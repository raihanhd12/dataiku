from typing import Dict, List, TypedDict


class DatasetMetadata(TypedDict, total=False):
    columns: List[str]


# --------------- 'Dataiku Answers' configuration dataset names ---------------
# Logging dataset:
LOGGING_DATASET_CONF_ID = "logging_dataset"
# User profile dataset:
USER_PROFILE_DATASET_CONF_ID = "user_profile_dataset"
# General feedback dataset:
GENERAL_FEEDBACK_DATASET_CONF_ID = "general_feedback_dataset"


# --------------- Dataset metadatas ---------------
ANSWERS_DATASETS_METADATA: Dict[str, DatasetMetadata] = {
    LOGGING_DATASET_CONF_ID: {
        "columns": [
            "conversation_id",
            "conversation_name",
            "knowledge_bank_id",
            "knowledge_bank_name",
            "llm_name",
            "user",
            "message_id",
            "question",
            "filters",
            "file_path",
            "answer",
            "sources",
            "feedback_value",
            "feedback_choice",
            "feedback_message",
            "timestamp",
            "state",
            "llm_context",
            "generated_media",
        ],
    },
    USER_PROFILE_DATASET_CONF_ID: {
        "columns": ["user", "profile", "last_updated"],
    },
    GENERAL_FEEDBACK_DATASET_CONF_ID: {
        "columns": ["date", "user", "message", "knowledgebank", "llm"],
    },
}

ANSWERS_CONFIG_DATASETS = list(ANSWERS_DATASETS_METADATA.keys())
