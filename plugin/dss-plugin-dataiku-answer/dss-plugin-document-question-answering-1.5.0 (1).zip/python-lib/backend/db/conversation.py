import concurrent.futures
import itertools
import json
import time
import uuid

# from datetime import datetime as dt
from enum import Enum
from typing import Dict, Generator, List, Literal, Optional, Union

import pandas as pd
from backend.db.sql.dataset_schemas import ANSWERS_DATASETS_METADATA, LOGGING_DATASET_CONF_ID
from backend.db.sql.queries import (
    DIALECT_VALUES,
    CreateIndexQueryBuilder,
    DeleteQueryBuilder,
    InsertQueryBuilder,
    UpdateQueryBuilder,
    WhereCondition,
    _get_where_and_cond,
    columns_in_uppercase,
    get_post_queries,
)
from backend.db.sql.sql_timing import log_query_time
from backend.models.base import (
    DOCUMENT_EXTENSIONS,
    IMAGE_EXTENSIONS,
    Conversation,
    ConversationInfo,
    ConversationType,
    Feedback,
    LlmHistory,
    MediaSummary,
    QuestionData,
    Source,
)
from backend.utils.dataiku_api import dataiku_api
from backend.utils.dataiku_utils import get_llm_friendly_name
from backend.utils.file_utils import load_pdf_images_from_file
from backend.utils.parameter_helpers import load_n_top_sources_to_log
from backend.utils.picture_utils import b64encode_image_from_path
from backend.utils.rag_sources import filter_chat_logs_rag_sources
from dataiku import Dataset, SQLExecutor2
from dataiku.sql import Column, Dialects, SelectQuery, toSQL
from dataiku.sql.expression import Operator
from llm_assist.logging import logger
from solutions.knowledge_bank import get_knowledge_bank_name
from werkzeug.exceptions import BadRequest


class RecordState(Enum):
    PRESENT = "present"
    DELETED = "deleted"
    CLEARED = "cleared"


LONGTEXT_MAX_LENGTH = 1000000000
LONGTEXT_COLUMN_NAMES = [
    "question",
    "filters",
    "file_path",
    "answer",
    "sources",
    "feedback_message",
    "llm_context",
    "generated_media",
]
CONVERSATION_DEFAULT_NAME = "New chat"


class ConversationSQL:
    def __init__(self):
        self.columns = ANSWERS_DATASETS_METADATA[LOGGING_DATASET_CONF_ID]["columns"]
        self.config = dataiku_api.webapp_config
        self.db_name = self.config.get(LOGGING_DATASET_CONF_ID, None)
        self.permanent_delete = self.config.get("permanent_delete", True)
        self.__verify()
        self.dataset = Dataset(project_key=dataiku_api.default_project_key, name=self.db_name)
        self.__init_dataset()
        self.executor = SQLExecutor2(dataset=self.dataset)
        dialect = self.dataset.get_config().get("type")
        if dialect == Dialects.MYSQL:
            self._update_mysql_dataset_schema()
        self.is_upper = False
        self.get_column_names()
        self.__init_indexes()
        self._init_thread_executor()

    def __verify(self):
        if self.db_name is None or self.db_name == "":
            logger.error("Logging Database name should not be null")
            raise ValueError("Logging Database name should not be null")
        self.__check_db_exists()
        self.__check_supported_dialect()

    def __check_db_exists(self):
        project = dataiku_api.client.get_project(dataiku_api.default_project_key)
        data = project.list_datasets()
        datasets = [item.name for item in data]
        logger.debug(f"Searching for {self.db_name} in this project datasets: {datasets}")
        if self.db_name in datasets:
            return True
        else:
            logger.error("Logging dataset does not exist")
            raise ValueError("Logging dataset does not exist")

    def __check_supported_dialect(self):
        # TODO: Limit dialects here is needed
        dataset = Dataset(project_key=dataiku_api.default_project_key, name=self.db_name)
        dataset_type = dataset.get_config().get("type")
        result = dataset_type in DIALECT_VALUES
        if result:
            return
        else:
            logger.error(f"Dataset Type {dataset_type} is not supported")
            raise ValueError(f"Dataset Type {dataset_type} is not supported")

    def _update_mysql_dataset_schema(self):
        logger.debug("Updating schema in case of mysql dialect")
        need_update = False
        try:
            schema = self.dataset.read_schema()
            new_schema = []
            for column in schema:
                if column["name"] in LONGTEXT_COLUMN_NAMES:
                    if column["maxLength"] != LONGTEXT_MAX_LENGTH:
                        need_update = True
                        column["maxLength"] = LONGTEXT_MAX_LENGTH
                new_schema.append(column)
            if need_update:
                self.dataset.write_schema(new_schema)
                logger.debug("Updated schema successfully")
            else:
                logger.debug("No need to alter schema. Schema is OK")
        except Exception as err:
            logger.error(err)
            raise BadRequest(f"Error when executing SQL query: {err}")

    def __init_dataset(self):
        try:
            self.dataset.read_schema(raise_if_empty=True)
        except Exception as e:
            logger.info("Initializing the dataset schema")
            df = self.get_init_df()
            self.dataset.write_with_schema(df=df)

    def __init_indexes(self) -> None:
        index_chat_history: bool = bool(self.config.get("index_chat_history", False))
        if not index_chat_history:
            return
        logger.debug("Creating indexes")
        indexes = [
            {"name": "user_index", "columns": ["user"]},
            {"name": "conversation_id_index", "columns": ["conversation_id"]},
            {"name": "timestamp_index", "columns": ["timestamp"]},
        ]

        for index in indexes:
            try:
                query = (
                    CreateIndexQueryBuilder(self.dataset)
                    .set_index_name(index["name"])
                    .add_columns(index["columns"])
                    .build()
                )
                self.executor.query_to_df(query, post_queries=get_post_queries(self.dataset))
                logger.debug(f"Index {index['name']} created")
            except Exception as err:
                logger.debug(f"Couldn't create index {index['name']} because Index may already exist. Proceeding...")
        return

    def _init_thread_executor(self):
        self.thread_executor = None
        max_thread_workers_number = self.config.get("max_thread_workers_number", 0)
        if max_thread_workers_number:
            logger.debug(f"Creating a new ThreadPoolExecutor with max_workers = {max_thread_workers_number}")
            self.thread_executor = concurrent.futures.ThreadPoolExecutor(max_workers=max_thread_workers_number)

    def get_init_df(self):
        data = {col: [] for col in self.columns}
        return pd.DataFrame(data=data, columns=self.columns, dtype=str)

    def col(self, col_name: str) -> str:
        if self.is_upper:
            return col_name.upper()
        return col_name

    def get_column_names(self):
        if columns_in_uppercase(self.dataset):
            self.is_upper = True
            self.columns = [col.upper() for col in self.columns]

    @log_query_time
    def select_columns_from_dataset(  # noqa: PLR0917 too many positional arguments
        self,
        column_names: List[str],
        distinct: bool = False,
        eq_cond: List[WhereCondition] = [],
        format_: Literal["dataframe", "iter"] = "dataframe",
        limit: Optional[int] = None,
        order_by: Optional[str] = None,
    ) -> pd.DataFrame:
        self.__validate_columns(column_names)
        columns_to_select = [Column(str(col)) for col in column_names]

        select_query = SelectQuery()
        if distinct:
            select_query.distinct()
        select_query.select_from(self.dataset)

        if column_names == self.columns:
            select_query.select(Column("*"))
        else:
            select_query.select(columns_to_select)

        where_cond = _get_where_and_cond(eq_cond)

        select_query.where(where_cond)

        if limit:
            select_query.limit(limit)

        if order_by:
            order_by_col = Column(str(order_by))
            select_query.order_by(order_by_col)

        response = self.execute(select_query, format_=format_)
        if type(response) is not pd.DataFrame:
            return pd.DataFrame()
        return response

    def execute(
        self,
        query_raw,
        format_: Literal["dataframe", "iter"] = "dataframe",
    ):
        try:
            query = toSQL(query_raw, dataset=self.dataset)
        except Exception as err:
            raise BadRequest(f"Error when generating SQL query: {err}")

        if format_ == "dataframe":
            try:
                query_result = self.executor.query_to_df(query=query).fillna("")
                query_result.columns = [col.lower() for col in query_result.columns]
                return query_result
            except Exception as err:
                raise BadRequest(f"Error when generating SQL query: {err}")
        elif format_ == "iter":
            try:
                query_result = self.executor.query_to_iter(query=query).iter_tuples()
                return query_result
            except Exception as err:
                raise BadRequest(f"Error when executing SQL query: {err}")

    def execute_commit(self):
        return

    def get_post_queries(self):
        dialect = self.dataset.get_config().get("type")
        # transaction control statement (like BEGIN, COMMIT, or ROLLBACK) are not supported by BigQuery
        return ["COMMIT"] if dialect != Dialects.BIGQUERY else None

    @log_query_time
    def get_user_conversations(self, auth_identifier: str):
        column_names = [
            self.col("user"),
            self.col("conversation_id"),
            self.col("conversation_name"),
            self.col("timestamp"),
            self.col("state"),
        ]
        order_by_column = self.col("timestamp")
        eq_cond = [
            WhereCondition(column=self.col("user"), operator=Operator.EQ, value=auth_identifier),
            WhereCondition(
                column=self.col("state"),
                operator=Operator.OR,
                value=[RecordState.PRESENT.value, RecordState.CLEARED.value],
            ),
        ]
        format_ = "dataframe"
        result: pd.DataFrame = self.select_columns_from_dataset(
            column_names=column_names,
            distinct=True,
            eq_cond=eq_cond,
            format_=format_,
            order_by=order_by_column,
        )
        conversations: Dict[str, ConversationInfo] = {}
        for index, row in result.iterrows():
            conversation_id = row["conversation_id"]
            if conversation_id not in conversations or row["timestamp"] < conversations[conversation_id]["timestamp"]:
                conversations[conversation_id] = ConversationInfo(
                    id=conversation_id,
                    name=row["conversation_name"],
                    timestamp=row["timestamp"],
                )
        return list(conversations.values())

    @log_query_time
    def get_conversation(self, auth_identifier: str, conversation_id: str, only_present: bool = True):
        eq_cond = [
            WhereCondition(column=self.col("user"), value=auth_identifier, operator=Operator.EQ),
            WhereCondition(column=self.col("conversation_id"), value=conversation_id, operator=Operator.EQ),
        ]
        if only_present:
            eq_cond.append(
                WhereCondition(column=self.col("state"), value=RecordState.PRESENT.value, operator=Operator.EQ)
            )
        format_ = "dataframe"
        order_by = self.col("message_id")
        result: pd.DataFrame = self.select_columns_from_dataset(
            column_names=self.columns,
            eq_cond=eq_cond,
            format_=format_,
            order_by=order_by,
        )
        return ConversationSQL.convert_query_result_to_conversation(result, only_present=True)

    def sql_query_to_df_with_error_handling(self, sql_query):
        try:
            return self.executor.query_to_df(sql_query, post_queries=get_post_queries(self.dataset))
        except Exception as e:
            logger.exception(f"Error when executing SQL query: {e}")

    def _execute_async_sql_tasks(self, sql_query):
        if self.thread_executor is None:
            self.sql_query_to_df_with_error_handling(sql_query)
        else:
            # Submit the task to the executor
            self.thread_executor.submit(self.sql_query_to_df_with_error_handling, sql_query)
            logger.debug("Task submitted to the executor")

    @log_query_time
    def add_record(  # noqa: PLR0917 too many positional arguments
        self,
        record: QuestionData,
        auth_identifier: str,
        conversation_id: Optional[str],
        conversation_name: Optional[str] = CONVERSATION_DEFAULT_NAME,
        knowledge_bank_id: Optional[str] = None,
        llm_id: Optional[str] = None,
    ):
        is_new_conversation = conversation_id is None
        if not is_new_conversation:
            record_id = str(record["id"])
        else:
            conversation_id = str(uuid.uuid4())
            record_id = str(0)

        n_top_sources_to_log = load_n_top_sources_to_log()
        filtered_sources, sources_has_been_filtered = filter_chat_logs_rag_sources(
            record["sources"], n_top_sources_to_log, None
        )
        llm_context = record.get("llm_context", {})
        generated_media = record.get("generated_media", {})
        timestamp = str(time.time())
        record_value = [
            conversation_id,
            conversation_name,
            knowledge_bank_id,
            get_knowledge_bank_name(knowledge_bank_id),
            get_llm_friendly_name(llm_id),
            auth_identifier,
            record_id,
            record["query"],
            json.dumps({"filters": record["filters"]}, ensure_ascii=False),
            record["file_path"],
            record["answer"],
            json.dumps({"sources": filtered_sources}, ensure_ascii=False),
            record["feedback"]["value"] if record["feedback"] else "",
            ";".join(record["feedback"]["choice"]) if record["feedback"] else "",
            record["feedback"]["message"] if record["feedback"] else "",
            # dt.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ"), # InsertQueryBuilder.get_wrapped_value seems forcing this to cast to TIMESTAMPTZ when calling ListBuilder
            # dt.now().strftime("%Y-%m-%d %H:%M:%S"), # using this time format to avoid the above problem.
            timestamp,
            RecordState.PRESENT.value,
            json.dumps(llm_context, ensure_ascii=False),
            json.dumps(generated_media),
        ]
        insert_query = (
            InsertQueryBuilder(self.dataset).add_columns(self.columns).add_values(values=[record_value]).build()
        )
        # logger.debug(insert_query)
        try:
            # Call the function that starts async tasks
            self._execute_async_sql_tasks(insert_query)
        except Exception as e:
            # Handle exceptions if necessary
            logger.error(e)
            raise BadRequest(f"Error when executing SQL query: {e}")
        return record_id, ConversationInfo(id=conversation_id, name=conversation_name, timestamp=timestamp)  # type: ignore

    @log_query_time
    def update_answer(
        self,
        auth_identifier: str,
        conversation_id: str,
        message_id: str,
        answer: str,
    ):
        update_query = (
            UpdateQueryBuilder(self.dataset)
            .add_set_cols([(self.col("answer"), answer)])
            .add_conds(
                [
                    WhereCondition(
                        column=self.col("conversation_id"),
                        value=conversation_id,
                        operator=Operator.EQ,
                    ),
                    WhereCondition(column=self.col("user"), value=auth_identifier, operator=Operator.EQ),
                    WhereCondition(column=self.col("message_id"), value=str(message_id), operator=Operator.EQ),
                ]
            )
            .build()
        )
        try:
            self.executor.query_to_df(update_query, post_queries=get_post_queries(self.dataset))
        except Exception as err:
            logger.error(err)
            raise BadRequest(f"Error when executing SQL query: {err}")

    @log_query_time
    def get_conversation_history(self, auth_identifier: str, conversation_id: str):
        conversation = self.get_conversation(auth_identifier=auth_identifier, conversation_id=conversation_id)
        if conversation:
            messages = []
            if conversation.get("media_summaries"):
                # Handle case of initial media summarization
                # TODO: consider removing media_summaries
                messages.append(
                    LlmHistory(
                        input="",
                        output=json.dumps({"uploaded_docs": conversation["media_summaries"]}),
                    )
                )
            for item in conversation["data"]:
                if item.get("answer"):
                    if item.get("uploaded_docs"):
                        # Handle the case when the user uploads docs with a query
                        messages.append(
                            LlmHistory(
                                input=json.dumps({"uploaded_docs": item["uploaded_docs"], "query": item["query"]}),
                                output=item["answer"],
                            )
                        )
                    else:
                        messages.append(LlmHistory(input=item["query"], output=item["answer"]))
                elif item.get("generated_media") and item.get("generated_media").get("images"):
                    messages.append(
                        LlmHistory(
                            input=item["query"], output=json.dumps({"generated_media_by_ai": item["generated_media"]})
                        )
                    )
                elif item.get("uploaded_docs") and not item.get("answer"):
                    # Handle the case when the user uploads docs for summary during an existing conversation
                    messages.append(
                        LlmHistory(input=item["query"], output=json.dumps({"uploaded_docs": item["uploaded_docs"]}))
                    )

            return messages, conversation["name"]
        return [], None

    @log_query_time
    def clear_conversation_history_permanent(self, auth_identifier: str, conversation_id: str):
        delete_query = (
            DeleteQueryBuilder(self.dataset)
            .add_conds(
                [
                    WhereCondition(
                        column=self.col("conversation_id"),
                        value=conversation_id,
                        operator=Operator.EQ,
                    ),
                    WhereCondition(column=self.col("user"), value=auth_identifier, operator=Operator.EQ),
                    WhereCondition(column=self.col("message_id"), value=str(0), operator=Operator.NE),
                ]
            )
            .build()
        )

        cols_to_keep = [
            self.col("conversation_id"),
            self.col("conversation_name"),
            self.col("user"),
            self.col("timestamp"),
            self.col("message_id"),
        ]

        set_cols = [
            (
                column,
                ""
                if (column != "sources" and column != "filters")
                else json.dumps({"filters": None}, ensure_ascii=False)
                if column == "filters"
                else json.dumps({"sources": []}, ensure_ascii=False),
            )
            for column in self.columns
            if column not in cols_to_keep
        ]

        set_cols.append((self.col("state"), RecordState.CLEARED.value))

        set_empty_record_query = (
            UpdateQueryBuilder(self.dataset)
            .add_conds(
                [
                    WhereCondition(
                        column=self.col("conversation_id"),
                        value=conversation_id,
                        operator=Operator.EQ,
                    ),
                    WhereCondition(column=self.col("user"), value=auth_identifier, operator=Operator.EQ),
                    WhereCondition(column=self.col("message_id"), value=str(0), operator=Operator.EQ),
                ]
            )
            .add_set_cols(set_cols)
            .build()
        )
        try:
            self.executor.query_to_df(delete_query, post_queries=get_post_queries(self.dataset))
            self.executor.query_to_df(set_empty_record_query, post_queries=get_post_queries(self.dataset))
        except Exception as err:
            logger.error(err)
            raise BadRequest(f"Error when executing SQL query: {err}")

    @log_query_time
    def clear_conversation_history_non_permanent(self, auth_identifier: str, conversation_id: str):
        update_query = (
            UpdateQueryBuilder(self.dataset)
            .add_set_cols([(self.col("state"), RecordState.CLEARED.value)])
            .add_conds(
                [
                    WhereCondition(
                        column=self.col("conversation_id"),
                        value=conversation_id,
                        operator=Operator.EQ,
                    ),
                    WhereCondition(column=self.col("user"), value=auth_identifier, operator=Operator.EQ),
                ]
            )
            .build()
        )

        try:
            self.executor.query_to_df(update_query, post_queries=get_post_queries(self.dataset))
        except Exception as err:
            logger.error(err)
            raise BadRequest(f"Error when executing SQL query: {err}")

    @log_query_time
    def clear_conversation_history(self, auth_identifier: str, conversation_id: str):
        # TODO: This one is tricky as we need a separate conversation dataset for this
        # Basic solution would be to delete everything except for the first message
        # and then update the message with blank answer and query
        if self.permanent_delete:
            self.clear_conversation_history_permanent(auth_identifier=auth_identifier, conversation_id=conversation_id)
        else:
            self.clear_conversation_history_non_permanent(
                auth_identifier=auth_identifier, conversation_id=conversation_id
            )

    @log_query_time
    def get_conversation_media_paths(self, auth_identifier: str, conversation_id: Optional[str] = None) -> List[str]:
        if dataiku_api.webapp_config.get("upload_folder") is None:
            return []
        media_columns = [
            self.col("llm_context"),
            self.col("generated_media"),
        ]
        if "file_path" in self.columns:  # TODO: legacy to remove later
            media_columns.append(self.col("file_path"))  # TODO: legacy to remove later
        eq_cond = [
            WhereCondition(column=self.col("user"), operator=Operator.EQ, value=auth_identifier),
            WhereCondition(
                column=self.col("state"),
                operator=Operator.OR,
                value=[RecordState.PRESENT.value, RecordState.CLEARED.value],
            ),
        ]
        if conversation_id:
            eq_cond.append(
                WhereCondition(column=self.col("conversation_id"), operator=Operator.EQ, value=conversation_id)
            )
        media_df = self.select_columns_from_dataset(
            column_names=media_columns,
            eq_cond=eq_cond,
        )
        if isinstance(media_df, Generator):
            return []
        if media_df.empty:
            return []

        legacy = []
        llm_context = media_df["llm_context"].dropna()
        generated_media = media_df["generated_media"].dropna()
        uploaded = ConversationSQL.get_paths_from_history(
            series=llm_context, data_key="media_qa_context", additional_file_name="metadata_path"
        )
        generated = ConversationSQL.get_paths_from_history(
            series=generated_media, data_key="images", additional_file_name="referred_file_path"
        )
        if "file_path" in self.columns:  # TODO: legacy to remove later
            legacy = media_df["file_path"].replace("", pd.NA).dropna().tolist()  # TODO: legacy to remove later
        return uploaded + generated + legacy

    @log_query_time
    def delete_user_conversation(self, auth_identifier: str, conversation_id: str) -> None:
        if self.permanent_delete:
            media_to_delete = self.get_conversation_media_paths(auth_identifier, conversation_id)
            if media_to_delete:
                logger.debug(f"Deleting media files: {media_to_delete}")
                ConversationSQL.delete_files(media_to_delete)
            query = (
                DeleteQueryBuilder(self.dataset)
                .add_conds(
                    [
                        WhereCondition(
                            column=self.col("conversation_id"),
                            value=conversation_id,
                            operator=Operator.EQ,
                        ),
                        WhereCondition(column=self.col("user"), value=auth_identifier, operator=Operator.EQ),
                    ]
                )
                .build()
            )
        else:
            query = (
                UpdateQueryBuilder(self.dataset)
                .add_set_cols([(self.col("state"), RecordState.DELETED.value)])
                .add_conds(
                    [
                        WhereCondition(
                            column=self.col("conversation_id"),
                            value=conversation_id,
                            operator=Operator.EQ,
                        ),
                        WhereCondition(column=self.col("user"), value=auth_identifier, operator=Operator.EQ),
                    ]
                )
                .build()
            )
        try:
            self.executor.query_to_df(query, post_queries=get_post_queries(self.dataset))
        except Exception as err:
            logger.error(err)
            raise BadRequest(f"Error when executing SQL query: {err}")

    @log_query_time
    def delete_all_user_conversations(self, auth_identifier: str) -> None:
        if self.permanent_delete:
            media_to_delete = self.get_conversation_media_paths(auth_identifier)
            if media_to_delete:
                logger.debug(f"Deleting media files: {media_to_delete}")
                ConversationSQL.delete_files(media_to_delete)
            query = (
                DeleteQueryBuilder(self.dataset)
                .add_conds([WhereCondition(column=self.col("user"), value=auth_identifier, operator=Operator.EQ)])
                .build()
            )
        else:
            query = (
                UpdateQueryBuilder(self.dataset)
                .add_set_cols([(self.col("state"), RecordState.DELETED.value)])
                .add_conds(
                    [
                        WhereCondition(column=self.col("user"), value=auth_identifier, operator=Operator.EQ),
                    ]
                )
                .build()
            )
        try:
            self.executor.query_to_df(query, post_queries=get_post_queries(self.dataset))
        except Exception as err:
            logger.error(err)
            raise BadRequest(f"Error when executing SQL query: {err}")

    @log_query_time
    def update_feedback(
        self,
        auth_identifier: str,
        conversation_id: str,
        message_id: str,
        feedback: Feedback,
    ):
        update_query = (
            UpdateQueryBuilder(self.dataset)
            .add_set_cols(
                [
                    (self.col("feedback_value"), feedback["value"]),
                    (self.col("feedback_message"), feedback["message"]),
                    (self.col("feedback_choice"), ";".join(feedback["choice"])),
                ]
            )
            .add_conds(
                [
                    WhereCondition(
                        column=self.col("conversation_id"),
                        value=conversation_id,
                        operator=Operator.EQ,
                    ),
                    WhereCondition(column=self.col("user"), value=auth_identifier, operator=Operator.EQ),
                    WhereCondition(column=self.col("message_id"), value=str(message_id), operator=Operator.EQ),
                ]
            )
            .build()
        )
        try:
            self.executor.query_to_df(update_query, post_queries=get_post_queries(self.dataset))
        except Exception as err:
            logger.error(err)
            raise BadRequest(f"Error when executing SQL query: {err}")

    def __validate_columns(self, column_names: List[str]):
        return all(name in self.columns for name in column_names)

    @staticmethod
    def convert_query_result_to_conversation(result: pd.DataFrame, only_present: bool = True):
        if result.empty:
            return None
        else:
            result = result.sort_values(by="message_id", ascending=True)
            id = result["conversation_id"].iloc[0]
            name = result["conversation_name"].iloc[0]
            timestamp = result["timestamp"].iloc[0]
            auth_identifier = result["user"].iloc[0]
            question_data: List[QuestionData] = []
            is_media_qa = False
            media_summaries = None
            for index, row in result.iterrows():
                if only_present and row["state"] != RecordState.PRESENT.value:
                    continue
                query = row["question"]
                answer = row["answer"]
                feedback_value = row["feedback_value"]
                feedback_choice = row["feedback_choice"]
                feedback_message = row["feedback_choice"]
                message_timestamp = row["timestamp"]
                record_id = row["message_id"]
                feedback = None
                generated_media = ConversationSQL.load_generated_media(row["generated_media"])
                # TODO: should all happen in load_sources
                sources = ConversationSQL.load_sources(row["sources"])
                filters = ConversationSQL.load_filters(row["filters"])
                # TODO: legacy code, remove later #####
                file_path = row["file_path"]
                if file_path:
                    if "." in file_path and file_path.rsplit(".", 1)[1].lower() in DOCUMENT_EXTENSIONS:
                        b64_image = load_pdf_images_from_file(file_path)
                        uploaded_image = f"data:image/png;base64,{b64_image}"
                    elif "." in file_path and file_path.rsplit(".", 1)[1].lower() in IMAGE_EXTENSIONS:
                        b64_image = b64encode_image_from_path(file_path)
                        uploaded_image = f"data:image/png;base64,{b64_image}"
                else:
                    uploaded_image = None
                #####################################
                llm_context = ConversationSQL.load_llm_context(row["llm_context"])
                llm_kb_selection = None
                llm_db_selection = None
                if llm_context is not None:
                    llm_kb_selection = llm_context.get("llm_kb_selection")
                    llm_db_selection = llm_context.get("dataset_context")
                if feedback_value:
                    feedback = Feedback(
                        value=feedback_value,
                        message=feedback_message if feedback_message else "",
                        choice=ConversationSQL.format_feedback_choice(feedback_choice),
                    )
                media_qa_context = llm_context.get("media_qa_context") if llm_context else None
                if media_qa_context is not None and index == 0:
                    is_media_qa = True
                    media_summaries = ConversationSQL.get_uploaded_docs(media_qa_context)
                uploaded_docs = None
                if uploaded_docs := llm_context.get("uploaded_docs", []):
                    if not query:
                        # The user uploads docs for summary during an existing conversation
                        uploaded_docs = ConversationSQL.get_uploaded_docs(uploaded_docs)
                    else:
                        # The user uploads docs with a query
                        uploaded_docs = ConversationSQL.get_uploaded_docs(uploaded_docs)
                question_data.append(
                    QuestionData(
                        id=record_id,
                        query=query,
                        answer=answer,
                        filters=filters,
                        file_path=file_path,
                        uploaded_image=uploaded_image,
                        sources=sources,
                        feedback=feedback,
                        timestamp=message_timestamp,
                        llm_kb_selection=llm_kb_selection,
                        llm_db_selection=llm_db_selection,
                        generated_media=generated_media,
                        uploaded_docs=uploaded_docs,
                    )
                )
            return Conversation(
                id=id,
                name=name,
                timestamp=timestamp,
                auth_identifier=auth_identifier,
                data=question_data,
                media_summaries=media_summaries,
                conversation_type=ConversationType.MEDIA_QA if is_media_qa else ConversationType.GENERAL,
            )

    @staticmethod
    def format_feedback_choice(choice: Optional[str]):
        if choice is None or choice == "":
            return []
        return [value.strip() for value in choice.split(";")]

    @staticmethod
    def load_sources(sources_str: str):
        sources_json = json.loads(sources_str)
        sources = sources_json.get("sources", [])
        result = [
            Source(
                excerpt=source.get("excerpt", ""), metadata=source.get("metadata", {}), sample=source.get("sample", {})
            )
            for source in sources
        ]
        return result

    @staticmethod
    def load_filters(filters_str: str):
        filters_json = json.loads(filters_str)
        filters = filters_json.get("filters", None)
        return filters

    @staticmethod
    def load_llm_context(llm_context: Optional[str]):
        return json.loads(llm_context) if llm_context else None

    @staticmethod
    def load_generated_media(generated_media: Optional[str]):
        return json.loads(generated_media) if generated_media else None

    @staticmethod
    def get_uploaded_docs(uploaded_media: List[MediaSummary]) -> Union[List[MediaSummary], None]:
        if not uploaded_media:
            return None
        folder = dataiku_api.folder_handle
        uploaded_doc_context = []
        try:
            # List all files in the managed folder
            file_list = folder.list_paths_in_partition()
            for media in uploaded_media:
                metadata_path: Optional[str] = media.get("metadata_path")
                if not metadata_path:
                    raise ValueError("metadata_path is missing")
                # Handle the case the file was deleted
                if "/" + metadata_path in file_list:
                    extract_summary = folder.read_json(metadata_path)
                    new_summary: MediaSummary = {**media, **extract_summary}
                    uploaded_doc_context.append(new_summary)
                else:
                    logger.info(f"The file {metadata_path} does not exist in the folder.")
                    uploaded_doc_context.append({**media, "is_deleted": True})
            return uploaded_doc_context
        except Exception as e:
            logger.error(f"Error occurred while retrieving uploaded media: {e}")
            return None

    @staticmethod
    def get_paths_from_history(series: pd.Series, data_key: str, additional_file_name: str) -> List[str]:
        def get_paths(row):
            if not row:
                return []
            media_qa_context = json.loads(row).get(data_key, [])
            return itertools.chain(
                (media.get(additional_file_name) for media in media_qa_context if media.get(additional_file_name)),
                (media.get("file_path") for media in media_qa_context if media.get("file_path")),
            )

        series = series.map(get_paths)  # type: ignore
        unique_values = list(set(item for sublist in series for item in sublist if item))
        return unique_values

    @staticmethod
    def delete_files(file_paths: List[str]) -> None:
        folder = dataiku_api.folder_handle
        for path in file_paths:
            try:
                folder.delete_path(path)
            except Exception as e:
                logger.error(f"Error occurred while deleting file: {e}")


conversation_sql_manager = ConversationSQL()
