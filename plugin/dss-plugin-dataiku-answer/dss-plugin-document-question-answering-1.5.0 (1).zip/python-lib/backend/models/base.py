from enum import Enum
from typing import Any, Dict, List, Optional, TypedDict, Union

from langchain.chains import ConversationChain
from solutions.chains.conversation_retrieval import DKUConversationRetrievalChain

# TODO: probably feedback needs to be handeled differently, not stored in cache


class Source(TypedDict, total=False):
    excerpt: Optional[str]
    metadata: Optional[Dict[str, Union[str, int, float]]]
    sample: Optional[Dict[str, Union[str, int, float]]]


class FeedbackValue(str, Enum):
    NEGATIVE = "NEGATIVE"
    POSITIVE = "POSITIVE"


class Feedback(TypedDict):
    value: FeedbackValue
    choice: List[str]
    message: str


class GeneratedMedia(TypedDict, total=False):
    file_data: str
    file_path: str
    file_format: str
    referred_file_path: str


class MediaSummary(TypedDict, total=False):
    original_file_name: str
    file_path: str
    metadata_path: str
    summary: Optional[str]
    topics: Optional[List[str]]
    questions: Optional[List[str]]
    full_extracted_text: Optional[str]
    preview: Optional[str]
    chain_type: Optional[str]
    token_estimate: Optional[int]
    is_deleted: Optional[bool]


class ConversationType(str, Enum):
    GENERAL = "general"
    MEDIA_QA = "media_qa"

class QuestionData(TypedDict, total=False):
    id: str
    query: str
    filters: Optional[Dict[str, List[Union[str, float, int]]]]
    file_path: Optional[str]
    chain_type: Optional[str]
    metadata_path: Optional[str]
    answer: str
    sources: List[Source]
    feedback: Optional[Feedback]
    timestamp: float
    llm_context: Optional[Dict[str, Any]]
    llm_kb_selection: Any
    llm_db_selection: Any
    generated_media: Optional[Dict[str, List[GeneratedMedia]]]
    generated_images: Optional[List[GeneratedMedia]]
    uploaded_docs: Optional[List[MediaSummary]]
    uploaded_image: Optional[str] #TODO legacy to remove

class Conversation(TypedDict):
    id: str
    name: str
    timestamp: float
    auth_identifier: str
    data: List[QuestionData]
    media_summaries: Optional[List[MediaSummary]]
    conversation_type: str


class ConversationInfo(TypedDict):
    id: str
    name: str
    timestamp: str


class LlmHistory(TypedDict):
    input: str
    output: str


class KnowledgeBankRetrievalParams(TypedDict):
    k: int
    search_type: str
    mmr_k: int
    mmr_diversity: float
    score_threshold: float


class KnowledgeBankParameters(TypedDict):
    id: str
    description: str
    name: str
    weight: float
    vector_db_type: str


PerKnowledgeBankParameters = Dict[str, KnowledgeBankParameters]

class ConversationParams(TypedDict, total=False):
    user_query: str
    chain_type: Optional[str]
    media_summaries: Optional[List[MediaSummary]]
    previous_media_summaries: Optional[List[MediaSummary]]
    retrieval_enabled: bool
    knowledge_bank_selection: List[str]
    chat_history: List[LlmHistory]
    kb_query: Optional[str]
    db_query: dict
    use_db_retrieval: bool
    filters: Optional[Dict[str, List[Any]]]
    qa_chain: Union[ConversationChain, DKUConversationRetrievalChain]
    global_start_time: float
    llm_capabilities: Dict[str, bool]
    justification: str
    user_profile: Optional[Dict[str, Any]]
    conversation_type: ConversationType
    self_service_decision: Optional[Dict[str, Union[str, List[str]]]]
    chain_purpose: Optional[str]


class ExtractedQueryInfo(TypedDict):
    query: str
    query_index: int
    filters: Optional[Dict[str, List[Any]]]
    chain_type: Optional[str]
    media_summaries: Optional[List[MediaSummary]]
    previous_media_summaries: Optional[List[MediaSummary]]
    conversation_name: Optional[str]
    history: List
    answer: str
    sources: List
    conversation_id: Optional[str]
    knowledge_bank_id: Optional[str]
    retrieval_enabled: bool
    retrieval_selection: Optional[Dict[str, List[Any]]]
    llm_context: Dict[str, Any]
    user_profile: Optional[Dict[str, Any]]
    generated_images: Optional[List[GeneratedMedia]]
    conversation_type: ConversationType

class LLMStep(Enum):
    COMPUTING_PROMPT_WITH_KB = 1
    COMPUTING_PROMPT_WITH_DB = 2
    COMPUTING_PROMPT_WITHOUT_RETRIEVAL = 3
    STREAMING_START = 4
    STREAMING_END = 5
    STREAMING_ERROR = 6
    QUERYING_LLM_WITHOUT_RETRIEVAL = 7
    QUERYING_LLM_WITH_KB = 8
    QUERYING_LLM_WITH_DB = 9
    GENERATING_IMAGE = 10


class RetrieverMode(Enum):
    KB = "kb"
    DB = "db"
    NO_RETRIEVER = "no_retrieval"


class RetrieverInfo(TypedDict):
    name: Optional[str]
    alias: Optional[str]
    activated: bool
    type: str
    id: Optional[str]
    
class UploadChainTypes(Enum):
    IMAGE = "image"
    DOCUMENT_AS_IMAGE = "document_as_image"
    SHORT_DOCUMENT = "short_document"
    LONG_DOCUMENT = "long_document"

class UploadFileError(Enum):
    GENERIC_ERROR = "generic_upload_error"
    NO_SELECTED_FILE = "no_selected_file"
    CONTEXT_EXCURSION = "context_excursion"
    INVALID_FILE_TYPE = "invalid_file_type"
    FILE_TOO_LARGE = "file_too_large"
    PARSING_ERROR = "parsing_error"
    TOO_MANY_FILES = "too_many_files"


class UploadFileResponse(TypedDict):
    media_summaries: List[MediaSummary]

IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "gif"}
DOCUMENT_EXTENSIONS = {"pdf", "docx", "py", "txt", "json", "html", "js"}
