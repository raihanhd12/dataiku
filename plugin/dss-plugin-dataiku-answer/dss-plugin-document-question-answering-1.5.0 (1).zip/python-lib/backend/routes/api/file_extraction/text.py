import tempfile
from typing import List, Optional, Union

from backend.db.sql.sql_timing import log_query_time
from backend.models.base import MediaSummary, UploadChainTypes, UploadFileError
from backend.utils.llm_utils import separator_length
from backend.utils.upload_utils import save_extracted_json
from langchain_community.document_loaders import Docx2txtLoader
from langchain_core.documents.base import Document
from llm_assist.logging import logger
from solutions.chains.text_extraction_summary_chain import get_text_extraction_summary


@log_query_time
def extract_plain_text(file_data: bytes) -> str:
    try:
        extracted_text = file_data.decode("utf-8", errors="replace")
        return extracted_text
    except Exception as e:
        logger.error(f"Error in extract_plain_text: {e}")
        raise Exception(UploadFileError.PARSING_ERROR.value)

@log_query_time
def extract_docx_text(file_data: bytes) -> str:
    try:
        with tempfile.NamedTemporaryFile(delete=True) as temp_file:
            temp_file.write(file_data)
            temp_file.flush()
            loader = Docx2txtLoader(temp_file.name)
            document: List[Document] = loader.load()

        extracted_text = ""
        for page in document:
            extracted_text += f"""{'-'*separator_length}
        page: {page.metadata.get('page', 'Unknown')}
        {page.page_content}
        """
        return extracted_text
    except Exception as e:
        logger.error(f"Error in extract_docx_text: {e}")
        raise Exception(UploadFileError.PARSING_ERROR.value)

@log_query_time
def extract_text_summary(file_path: str, file_data: bytes, secure_name: str, extension: str, language: Optional[str], start_time: str) -> MediaSummary:
    extracted_text: str
    media_summary: Union[MediaSummary, None]
    if extension == "docx":
        extracted_text = extract_docx_text(file_data)
    else:
        extracted_text = extract_plain_text(file_data)
    media_summary, error_message = get_text_extraction_summary(extracted_text, secure_name, language, start_time)
    if not media_summary and error_message:
        raise Exception(error_message)
    if media_summary is None:
        raise Exception(UploadFileError.PARSING_ERROR.value)
    if media_summary.get("summary") is None:
        media_summary["chain_type"] = UploadChainTypes.LONG_DOCUMENT.value
    else:
        media_summary["chain_type"] = UploadChainTypes.SHORT_DOCUMENT.value
    media_summary = {
        **media_summary,
        "file_path": file_path,
        "preview": None,
        "full_extracted_text": extracted_text,
    }
    metadata_path: str = save_extracted_json(file_path, media_summary or {})
    media_summary["metadata_path"] = metadata_path
    del media_summary["full_extracted_text"]
    return media_summary
