import base64
from io import BytesIO
from typing import Optional

from backend.db.sql.sql_timing import log_query_time
from backend.models.base import MediaSummary, UploadChainTypes, UploadFileError
from backend.routes.api.config import PREVIEW_IMAGE_LONGSIDE, PREVIEW_IMAGE_SHORT_SIDE
from backend.utils.upload_utils import save_extracted_json
from llm_assist.logging import logger
from PIL import Image
from solutions.chains.image_summary_chain import get_image_summary


@log_query_time
def extract_image_summary(
    file_path: str, file_data: bytes, original_file_name: str, language: Optional[str], start_time: str
) -> MediaSummary:
    summary: Optional[MediaSummary] = None
    error_message: Optional[str] = None
    try:
        image = Image.open(BytesIO(file_data))
        width, height = image.size

        if width > height:
            resized_image = image.resize((PREVIEW_IMAGE_LONGSIDE, PREVIEW_IMAGE_SHORT_SIDE))
        elif height > width:
            resized_image = image.resize((PREVIEW_IMAGE_SHORT_SIDE, PREVIEW_IMAGE_LONGSIDE))
        else:
            resized_image = image.resize((PREVIEW_IMAGE_SHORT_SIDE, PREVIEW_IMAGE_SHORT_SIDE))

        buffered = BytesIO()
        resized_image.save(buffered, format="PNG")
        b64_image = base64.b64encode(buffered.getvalue()).decode("utf-8")
        preview = f"data:image/png;base64,{b64_image}"
        chain_type = UploadChainTypes.IMAGE
        summary, error_message = get_image_summary(b64_image, original_file_name, language, start_time)
        if summary is None and error_message:
            raise Exception(error_message)
        if summary is None:
            raise Exception(UploadFileError.PARSING_ERROR.value)
        summary["preview"] = preview
        summary = MediaSummary(**summary)
        metadata_path: str = save_extracted_json(file_path, summary)
        summary = {**summary, "file_path": file_path, "metadata_path": metadata_path, "chain_type": chain_type.value}
        return summary
    except Exception as e:
        logger.error(f"Error during uploaded image parsing: {e}")
        if error_message:
            raise e
        raise Exception(UploadFileError.PARSING_ERROR.value)
