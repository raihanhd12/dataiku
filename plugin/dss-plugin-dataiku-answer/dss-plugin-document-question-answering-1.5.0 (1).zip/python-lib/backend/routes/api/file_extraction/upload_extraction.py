import time
from datetime import datetime
from typing import Dict, List, Optional, Union

from backend.db.user_profile import user_profile_sql_manager
from backend.models.base import (
    DOCUMENT_EXTENSIONS,
    IMAGE_EXTENSIONS,
    MediaSummary,
    UploadChainTypes,
    UploadFileError,
    UploadFileResponse,
)
from backend.routes.api.file_extraction.image import extract_image_summary
from backend.routes.api.file_extraction.pdf import extract_pdf_summary
from backend.routes.api.file_extraction.text import extract_text_summary
from backend.utils.context_utils import TIME_FORMAT, reset_llm_step_metrics
from backend.utils.dataiku_api import dataiku_api
from backend.utils.file_utils import allowed_file, upload_file
from backend.utils.llm_utils import get_llm_capabilities
from backend.utils.upload_utils import get_checked_config
from llm_assist.logging import logger
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

webapp_config: Dict[str, str] = dataiku_api.webapp_config
max_n_files = int(get_checked_config("max_n_upload_files"))
multi_modal: bool = get_llm_capabilities().get("multi_modal", False)


class UploadFileExtractor:
    def __init__(self, files: List[FileStorage], auth_identifier: str, language: str) -> None:
        reset_llm_step_metrics()
        if len(files) > max_n_files:
            raise Exception(UploadFileError.TOO_MANY_FILES.value)
        self.files = files
        self.auth_identifier = auth_identifier
        self.language = language
        self.multi_modal = multi_modal
        self.folder = dataiku_api.folder_handle

        self.extractions: UploadFileResponse = {"media_summaries": []}
        self.current_file_path: Union[str, None] = None
        self.current_summary: MediaSummary = {}

    def extract(self) -> UploadFileResponse:
        for file in self.files:
            if file.filename == "" or file.filename is None:
                raise Exception(UploadFileError.NO_SELECTED_FILE.value)
            extension_allowed, extension = allowed_file(file.filename, self.multi_modal)

            if file and extension_allowed:
                start_time: str = datetime.now().strftime(TIME_FORMAT)
                secure_name = secure_filename(file.filename)
                file_name = secure_filename(f"{int(time.time())}_{secure_name}")
                logger.debug(f"Uploading file name: {file_name}")
                self.current_file_path = f"{self.auth_identifier}/{file_name}"
                file_data: bytes = upload_file(file, self.current_file_path)
                if extension in IMAGE_EXTENSIONS:
                    self.current_summary = extract_image_summary(
                        self.current_file_path, file_data, secure_name, self.language, start_time
                    )
                elif extension == "pdf":
                    self.current_summary = extract_pdf_summary(
                        self.current_file_path, file_data, secure_name, self.language, start_time
                    )
                elif extension in DOCUMENT_EXTENSIONS:
                    self.current_summary = extract_text_summary(
                        self.current_file_path, file_data, secure_name, extension, self.language, start_time
                    )
                else:
                    raise Exception(UploadFileError.INVALID_FILE_TYPE.value)
                if self.current_summary.get("chain_type", "") == UploadChainTypes.LONG_DOCUMENT.value:
                    # TODO: This is just a temporary blocking of documents larger than context
                    # It should be removed once in memory RAG is enabled
                    raise Exception(UploadFileError.CONTEXT_EXCURSION.value)
                self.current_summary["original_file_name"] = secure_name
                self.extractions["media_summaries"].append(self.current_summary)
            else:
                raise Exception(UploadFileError.INVALID_FILE_TYPE.value)
        return self.extractions

    def clean_up(self) -> None:
        if file_path := self.current_file_path:
            self.folder.delete_path(file_path)
        if metadata_path := self.current_summary.get("metadata_path"):
            self.folder.delete_path(metadata_path)

    @staticmethod
    def get_user_language(auth_identifier: str) -> str:
        user_profile: Optional[Dict[str, str]] = user_profile_sql_manager.get_user_profile(auth_identifier)
        if isinstance(user_profile, dict):
            if user_language := str(user_profile.get("language", "en")):
                return user_language
        return "English"

