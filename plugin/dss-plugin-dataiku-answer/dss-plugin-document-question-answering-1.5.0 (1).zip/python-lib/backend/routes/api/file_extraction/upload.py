import base64
import time
from io import BytesIO
from typing import Dict, List, Union

from backend.models.base import (
    DOCUMENT_EXTENSIONS,
    IMAGE_EXTENSIONS,
    MediaSummary,
    UploadChainTypes,
    UploadFileError,
    UploadFileResponse,
)
from backend.routes.api.config import PREVIEW_IMAGE_LONGSIDE, PREVIEW_IMAGE_SHORT_SIDE
from backend.routes.api.file_extraction.pdf import extract_pdf_text, first_page_to_preview
from backend.routes.api.file_extraction.text import extract_docx_text, extract_plain_text
from backend.utils.dataiku_api import dataiku_api
from backend.utils.file_utils import allowed_file, upload_file
from backend.utils.llm_utils import get_llm_capabilities
from backend.utils.upload_utils import get_checked_config, save_extracted_json
from llm_assist.logging import logger
from PIL import Image
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

webapp_config: Dict[str, str] = dataiku_api.webapp_config
max_n_files = int(get_checked_config("max_n_upload_files"))
multi_modal: bool = get_llm_capabilities().get("multi_modal", False)


def save_uploads(files: List[FileStorage], auth_identifier: str) -> UploadFileResponse:
    extractions: UploadFileResponse = {"media_summaries": []}
    if len(files) > max_n_files:
        raise Exception(UploadFileError.TOO_MANY_FILES.value)
    for file in files:
        if file.filename == "" or file.filename is None:
            raise Exception(UploadFileError.NO_SELECTED_FILE.value)
        extension_allowed, extension = allowed_file(file.filename, multi_modal)

        if file and extension_allowed:
            secure_name = secure_filename(file.filename)
            file_name = secure_filename(f"{int(time.time())}_{secure_name}")
            logger.debug(f"Uploading file name: {file_name}")
            file_path = f"{auth_identifier}/{file_name}"
            file_data: bytes = upload_file(file, file_path)

            chain_type = ""
            preview = None
            extracted_text = None
            b64_image = ""
            if extension in IMAGE_EXTENSIONS:
                image = Image.open(BytesIO(file_data))
                width, height = image.size
                if width > height:
                    resized_image = image.resize((PREVIEW_IMAGE_LONGSIDE, PREVIEW_IMAGE_SHORT_SIDE))
                elif height > width:
                    resized_image = image.resize((PREVIEW_IMAGE_SHORT_SIDE, PREVIEW_IMAGE_LONGSIDE))
                else:
                    resized_image = image.resize((PREVIEW_IMAGE_SHORT_SIDE, PREVIEW_IMAGE_SHORT_SIDE))
                buffered = BytesIO()
                resized_image.save(buffered, format="PNG")
                b64_image = base64.b64encode(buffered.getvalue()).decode("utf-8")
                preview = f"data:image/png;base64,{b64_image}"
                chain_type = UploadChainTypes.IMAGE.value

            elif extension == "pdf":
                extracted_text, is_doc_as_image = extract_pdf_text(file_data)
                b64_image = first_page_to_preview(file_data)
                preview = f"data:image/png;base64,{b64_image}"
                if is_doc_as_image:
                    chain_type = UploadChainTypes.DOCUMENT_AS_IMAGE.value
                else:
                    # TODO: add in memory RAG HERE when needed UploadChainTypes.LONG_DOCUMENT.value
                    chain_type = UploadChainTypes.SHORT_DOCUMENT.value
            elif extension in DOCUMENT_EXTENSIONS:
                chain_type = UploadChainTypes.SHORT_DOCUMENT.value
                media_summary: Union[MediaSummary, None]
                if extension == "docx":
                    extracted_text = extract_docx_text(file_data)
                else:
                    extracted_text = extract_plain_text(file_data)
            else:
                raise Exception(UploadFileError.INVALID_FILE_TYPE.value)
            # if extraction then extract else just save
            media_summary = MediaSummary(
                    chain_type=chain_type,
                    original_file_name=file.filename,
                    file_path=file_path,
                    full_extracted_text=extracted_text,
                    preview=preview,
            )
            metadata_path: str = save_extracted_json(file_path, media_summary or {})
            media_summary["metadata_path"] = metadata_path
            del media_summary["full_extracted_text"]
            extractions["media_summaries"].append(media_summary)
        else:
            raise Exception(UploadFileError.INVALID_FILE_TYPE.value)
    return extractions
