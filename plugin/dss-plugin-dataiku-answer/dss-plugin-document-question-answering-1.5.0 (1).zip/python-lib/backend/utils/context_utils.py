from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from llm_assist.logging import logger

TIME_FORMAT = "%Y-%d-%m %H:%M:%S.%f"
TURN_OFF_COST_LOGGING = True


class LLMStepName(Enum):
    UNKNOWN = "Unknown"
    CONVERSATION_TITLE = "Get conversation title"
    SUMMARY_TITLE = "Get summary title"
    START_MEDIA_QA_CONVERSATION = "Start a media QA conversation"
    DECISION_SELF_SERVICE = "Get decision as JSON: self-service"
    IMAGE_SUMMARY = "Visual Question Answering (VQA) Chain: get image summary"
    DOC_AS_IMAGE_SUMMARY = "Visual Question Answering (VQA) Chain: get summary"
    DOC_AS_IMAGE_ANSWER = "Visual Question Answering (VQA) Chain: answer"
    TEXT_EXTRACTION_SUMMARY = "Text Extraction: summary"
    TEXT_EXTRACTION_ANSWER = "Text Extraction: answer"
    KB_AUTO_FILTERING = "KBRetrievalChain : auto filtering"
    KB_RETRIEVAL_QUERY = "KBRetrievalChain : retrieval query"
    KB_ANSWER = "KBRetrievalChain : answer"
    DB_RETRIEVAL_QUERY = "DBRetrievalChain : retrieval query"
    DB_RETRIEVAL_GRAPH = "DBRetrievalChain : retrieval graph"
    DB_FIX_RETRIEVAL_QUERY = "DBRetrievalChain : fix retrieval query"
    DB_ANSWER = "DBRetrievalChain : answer"
    DECISION_IMAGE_GENERATION = "Get decision as JSON: image generation"
    IMAGE_GENERATION = "Image Generation Chain (does not count tokens)"
    NO_RETRIEVAL = "No Retrieval Used Chain"


@dataclass
class LLMStepMetrics:
    step_start_time: str
    step_name: str = LLMStepName.UNKNOWN.value
    time_taken_seconds: Optional[float] = field(default=None, repr=False)
    prompt_tokens: Optional[int] = field(default=None, repr=False)
    completion_tokens: Optional[int] = field(default=None, repr=False)
    total_tokens: Optional[int] = field(default=None, repr=False)
    token_counts_are_estimated: Optional[bool] = field(default=None, repr=False)
    from_cache: Optional[bool] = field(default=None, repr=False)
    document_name: Optional[str] = field(default=None, repr=False)
    estimated_cost: Optional[float] = field(default=None, repr=False)

    def stop_timer(self) -> None:
        self.time_taken_seconds = round(
            (datetime.now() - datetime.strptime(self.step_start_time, TIME_FORMAT)).total_seconds(), 2
        )

    def to_dict(self) -> Dict[str, Any]:
        if TURN_OFF_COST_LOGGING:
            return {k: v for k, v in self.__dict__.items() if v is not None and k != "estimated_cost"}
        return {k: v for k, v in self.__dict__.items() if v is not None}

    def __repr__(self) -> str:
        available_fields = str(self.to_dict())
        if self.token_counts_are_estimated:
            return f"(Estimation only): {available_fields})"
        return available_fields


llm_step_metrics: ContextVar[List[LLMStepMetrics]] = ContextVar("llm_step_metrics", default=[])


def init_user_data() -> None:
    llm_step_metrics.set([])


def add_llm_step_metrics(llm_step: LLMStepMetrics) -> None:
    current_steps = llm_step_metrics.get()
    new_steps = current_steps + [llm_step]
    llm_step_metrics.set(new_steps)


def reset_llm_step_metrics() -> None:
    logger.debug("Resetting llm_step_metrics")
    init_user_data()


def log_llm_step_metrics() -> None:
    logger.debug(f"LLM steps:{[repr(step) for step in llm_step_metrics.get()]}")


def get_llm_step_dicts() -> List[Dict[str, Any]]:
    return [step.to_dict() for step in llm_step_metrics.get()]
