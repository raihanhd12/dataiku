import json
import re
from typing import Any, Dict

from llm_assist.logging import logger


def extract_json(response_text: str) -> Dict[str, Any]:
    # Find all characters that could be the start or end of a JSON object
    json_objects = re.findall(r"{[\s\S]*?}", response_text)
    # Find the longest string that could be a JSON object,
    # since it's most likely to be the correct one
    longest_json = max(json_objects, key=len, default="{}")
    # Convert the string back to a dictionary (JSON object)
    try:
        json_data: Dict[str, Any] = json.loads(longest_json)
    except json.JSONDecodeError as e:
        logger.exception("Error parsing json")
        # In case JSON decoding fails, just return an empty dictionary
        json_data = {}

    return json_data