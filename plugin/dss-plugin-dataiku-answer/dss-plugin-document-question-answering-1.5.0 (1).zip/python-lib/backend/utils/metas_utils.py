import ast


def is_string_list_representation(string):
    try:
        _ = ast.literal_eval(string)
        return isinstance(_, list)
    except:
        return False

def convert_to_list(string):
    try:
        return ast.literal_eval(string)
    except:
        return string 