import base64
from io import BytesIO
from typing import Dict, List, Tuple

import dataiku
import pypdfium2 as pdfium  # type: ignore
from backend.models.base import (
    DOCUMENT_EXTENSIONS,
    IMAGE_EXTENSIONS,
    UploadFileError,
)
from backend.utils.dataiku_api import dataiku_api
from backend.utils.upload_utils import get_checked_config
from llm_assist.logging import logger
from werkzeug.datastructures import FileStorage

webapp_config: Dict[str, str] = dataiku_api.webapp_config


def load_pdf_images_from_file(file_path: str) -> List[str]:
    folder = dataiku.Folder(webapp_config.get("upload_folder"))
    b64_images = []
    try:
        with folder.get_download_stream(file_path) as f:
            pdf_bytes = f.read()
            pdf_document = pdfium.PdfDocument(pdf_bytes)
        for page in pdf_document:
            pil_image = page.render().to_pil()
            with BytesIO() as buffered:
                pil_image.save(buffered, format="PNG")
                b64_image = base64.b64encode(buffered.getvalue()).decode("utf-8")
                b64_images.append(b64_image)
        del pil_image
        del b64_image
        return b64_images
    except IOError as e:
        logger.error(f"Unable to parse document to image: {e}")
        raise Exception(f"Unable to parse document to image: {e}")


def allowed_file(filename: str, multi_modal: bool) -> Tuple[bool, str]:
    allowed_extensions = DOCUMENT_EXTENSIONS
    if multi_modal:
        allowed_extensions = allowed_extensions.union(IMAGE_EXTENSIONS)
    if "." not in filename:
        raise Exception(UploadFileError.INVALID_FILE_TYPE.value)
    extension = filename.rsplit(".", 1)[1].lower()
    return extension in allowed_extensions, extension


def upload_file(file: FileStorage, file_path: str) -> bytes:
    file_data: bytes
    max_size_mb = int(get_checked_config("max_upload_size_mb"))
    max_content_length = max_size_mb * 1024 * 1024
    file_data = file.read()
    if len(file_data) == 0:
        raise Exception(UploadFileError.NO_SELECTED_FILE.value)
    if len(file_data) > max_content_length:
        raise Exception(UploadFileError.FILE_TOO_LARGE.value)
    file.seek(0)
    dataiku.Folder(webapp_config.get("upload_folder")).upload_stream(file_path, file)
    return file_data