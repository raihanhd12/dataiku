# Changelog

## [Version 2.1.0](https://github.com/dataiku/dss-plugin-nlp-embedding/releases/tag/v2.1.0) - 2023-04

- ✨ Python 3.8 to 3.10 support & fix Word2vec

## [Version 2.0.0](https://github.com/dataiku/dss-plugin-nlp-embedding/releases/tag/v2.0.0) - Python 3 - 2022-09

- ✨ Python 3 support & various bugfixes
