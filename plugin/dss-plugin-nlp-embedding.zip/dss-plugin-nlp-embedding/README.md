﻿# Sentence Embedding

This Dataiku DSS plugin provides a tool for computing numerical sentence representations (also known as **Sentence Embeddings**).

Documentation: https://www.dataiku.com/dss/plugins/info/sentence-embedding.html

## Licence

This plugin is distributed under Apache License version 2.0
